'use client';

import { useEffect, useRef, useState } from 'react';
import AppShell from '@/components/AppShell';
import { useAuth } from '@/lib/auth';
import { authAPI, attendanceAPI } from '@/lib/api';
import toast from 'react-hot-toast';
import {
  Briefcase,
  Building2,
  CalendarCheck,
  Camera,
  CreditCard,
  Eye,
  EyeOff,
  Fingerprint,
  KeyRound,
  Lock,
  Mail,
  Save,
  Shield,
  UserCircle,
} from 'lucide-react';
import { formatDate, getStatusTone } from '@/lib/utils';

export default function ProfilePage() {
  const { user, updateUser, refreshUser } = useAuth();

  // Profile fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Bank detail fields
  const [bankName, setBankName] = useState('');
  const [bankAccountNo, setBankAccountNo] = useState('');
  const [confirmAccountNo, setConfirmAccountNo] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [branchName, setBranchName] = useState('');
  const [savingBank, setSavingBank] = useState(false);

  // Profile photo
  const avatarRef = useRef(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);

  // Password section toggle
  const [showChangePw, setShowChangePw] = useState(false);

  // Password change fields
  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' });
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  // HR-set password visibility
  const [showTempPw, setShowTempPw] = useState(false);

  // Recent attendance
  const [recentAttendance, setRecentAttendance] = useState([]);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setPhone(user.phone || '');
      setBankName(user.bankName || '');
      setBankAccountNo(user.bankAccountNo || '');
      setConfirmAccountNo(user.bankAccountNo || '');
      setIfscCode(user.ifscCode || '');
      setBranchName(user.branchName || '');
      setAvatarPreview(null); // reset preview when user updates
      loadRecentAttendance();
    }
  }, [user]);

  const loadRecentAttendance = async () => {
    if (!user) return;
    const today = new Date();
    try {
      const { data } = await attendanceAPI.getMyMonth(today.getMonth() + 1, today.getFullYear());
      const sorted = [...(data.records || [])].sort((a, b) => new Date(b.date) - new Date(a.date));
      setRecentAttendance(sorted.slice(0, 8));
    } catch { /* silent */ }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1.5 * 1024 * 1024) {
      toast.error('Image must be smaller than 1.5 MB.');
      return;
    }
    setUploadingAvatar(true);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const dataUrl = ev.target.result;
      setAvatarPreview(dataUrl);
      try {
        const { data } = await authAPI.updateMe({ avatar: dataUrl, profilePic: dataUrl });
        updateUser(data.user, null);
        toast.success('Profile photo updated.');
      } catch (err) {
        toast.error(err.response?.data?.message || 'Failed to update photo.');
        setAvatarPreview(null);
      } finally {
        setUploadingAvatar(false);
      }
    };
    reader.onerror = () => {
      toast.error('Failed to read image file.');
      setUploadingAvatar(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const { data } = await authAPI.updateMe({ name, phone });
      updateUser(data.user, null);
      toast.success('Profile updated.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update profile.');
    } finally {
      setSavingProfile(false);
    }
  };

  const handleSaveBank = async (e) => {
    e.preventDefault();
    if (bankAccountNo !== confirmAccountNo) {
      toast.error('Account numbers do not match.');
      return;
    }
    setSavingBank(true);
    try {
      const { data } = await authAPI.updateMe({ bankName, bankAccountNo, ifscCode, branchName });
      updateUser(data.user, null);
      toast.success('Bank details updated.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update bank details.');
    } finally {
      setSavingBank(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (pwForm.newPw !== pwForm.confirm) {
      toast.error('New passwords do not match.');
      return;
    }
    if (pwForm.newPw.length < 6) {
      toast.error('New password must be at least 6 characters.');
      return;
    }
    setSavingPw(true);
    try {
      await authAPI.changePassword(pwForm.current, pwForm.newPw);
      toast.success('Password changed successfully.');
      setPwForm({ current: '', newPw: '', confirm: '' });
      setShowChangePw(false);
      await refreshUser();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to change password.');
    } finally {
      setSavingPw(false);
    }
  };

  const currentAvatar = avatarPreview || user?.avatar || user?.profilePic;

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl space-y-6">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">My Profile</h1>
          <p className="mt-1 text-sm text-surface-400">Manage your personal details and security settings.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* ── Identity card ────────────────────────────────────── */}
          <div className="glass-card p-6 text-center lg:col-span-1">

            {/* Avatar with upload button */}
            <div className="relative mx-auto mb-4 h-24 w-24">
              {currentAvatar ? (
                <img
                  src={currentAvatar}
                  alt={user?.name}
                  className="h-24 w-24 rounded-full object-cover ring-4 ring-brand-100"
                />
              ) : (
                <div className="flex h-24 w-24 items-center justify-center rounded-full bg-brand-100 ring-4 ring-brand-50">
                  <span className="text-3xl font-bold text-brand-700">
                    {user?.name?.charAt(0)?.toUpperCase() || '?'}
                  </span>
                </div>
              )}
              {/* Upload overlay button */}
              <button
                type="button"
                onClick={() => avatarRef.current?.click()}
                disabled={uploadingAvatar}
                className="absolute bottom-0 right-0 flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-white shadow-lg transition hover:bg-brand-700 disabled:opacity-60"
                title="Change profile photo"
              >
                {uploadingAvatar ? (
                  <span className="block h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                ) : (
                  <Camera className="h-3.5 w-3.5" />
                )}
              </button>
              <input
                ref={avatarRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleAvatarChange}
              />
            </div>

            <h3 className="font-display text-lg font-bold text-gray-900">{user?.name}</h3>
            <p className="text-sm capitalize text-surface-400">{user?.role}</p>

            {/* Info rows */}
            <div className="mt-6 space-y-3 text-left">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="h-4 w-4 flex-shrink-0 text-surface-400" />
                <span className="truncate text-gray-700">{user?.email}</span>
              </div>
              {user?.phone && (
                <div className="flex items-center gap-3 text-sm">
                  <UserCircle className="h-4 w-4 flex-shrink-0 text-surface-400" />
                  <span className="text-gray-700">{user.phone}</span>
                </div>
              )}
              {user?.department && (
                <div className="flex items-center gap-3 text-sm">
                  <Building2 className="h-4 w-4 flex-shrink-0 text-surface-400" />
                  <span className="text-gray-700">{user.department}</span>
                </div>
              )}
              {user?.designation && (
                <div className="flex items-center gap-3 text-sm">
                  <Briefcase className="h-4 w-4 flex-shrink-0 text-surface-400" />
                  <span className="text-gray-700">{user.designation}</span>
                </div>
              )}
              {user?.employeeId && (
                <div className="flex items-center gap-3 text-sm">
                  <Fingerprint className="h-4 w-4 flex-shrink-0 text-surface-400" />
                  <span className="font-mono text-gray-700">{user.employeeId}</span>
                </div>
              )}
              <div className="flex items-center gap-3 text-sm">
                <Shield className="h-4 w-4 flex-shrink-0 text-surface-400" />
                <span
                  className={`status-badge text-xs ${
                    user?.role === 'hr' ? 'bg-purple-100 text-purple-700' : 'bg-brand-100 text-brand-700'
                  }`}
                >
                  {user?.role?.toUpperCase()}
                </span>
              </div>

              {/* HR-set password — shown until employee changes it themselves */}
              {user?.tempPassword && (
                <div className="rounded-2xl border border-amber-200 bg-amber-50 p-3">
                  <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-amber-700">
                    Current Password
                  </p>
                  <div className="flex items-center justify-between gap-2">
                    <span className="break-all font-mono text-sm text-gray-900">
                      {showTempPw
                        ? user.tempPassword
                        : '•'.repeat(Math.min(user.tempPassword.length, 12))}
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowTempPw((v) => !v)}
                      className="flex-shrink-0 text-amber-600 hover:text-amber-800"
                      title={showTempPw ? 'Hide' : 'Show'}
                    >
                      {showTempPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <p className="mt-1.5 text-xs text-amber-600 leading-relaxed">
                    Set by HR. Change your password to secure your account.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* ── Right column ─────────────────────────────────────── */}
          <div className="space-y-6 lg:col-span-2">

            {/* Profile update */}
            <div className="glass-card p-6">
              <h3 className="mb-4 font-display font-bold text-gray-900">Update Profile</h3>
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="input-field"
                    placeholder="+91 9876543210"
                  />
                </div>
                <button type="submit" disabled={savingProfile} className="btn-primary">
                  <Save className="h-4 w-4" />
                  {savingProfile ? 'Saving...' : 'Save Changes'}
                </button>
              </form>
            </div>

            {/* Bank Details */}
            <div className="glass-card p-6">
              <div className="mb-4 flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-surface-400" />
                <h3 className="font-display font-bold text-gray-900">Bank Details</h3>
              </div>
              <form onSubmit={handleSaveBank} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Bank Name
                    </label>
                    <input
                      type="text"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      className="input-field"
                      placeholder="e.g. State Bank of India"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Branch Name
                    </label>
                    <input
                      type="text"
                      value={branchName}
                      onChange={(e) => setBranchName(e.target.value)}
                      className="input-field"
                      placeholder="e.g. Andheri West"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Account Number
                  </label>
                  <input
                    type="text"
                    value={bankAccountNo}
                    onChange={(e) => setBankAccountNo(e.target.value)}
                    className="input-field"
                    placeholder="Enter account number"
                    maxLength={20}
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Confirm Account Number
                  </label>
                  <input
                    type="text"
                    value={confirmAccountNo}
                    onChange={(e) => setConfirmAccountNo(e.target.value)}
                    className="input-field"
                    placeholder="Re-enter account number"
                    maxLength={20}
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    IFSC Code
                  </label>
                  <input
                    type="text"
                    value={ifscCode}
                    onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                    className="input-field font-mono"
                    placeholder="e.g. SBIN0001234"
                    maxLength={11}
                  />
                </div>
                <button type="submit" disabled={savingBank} className="btn-primary">
                  <Save className="h-4 w-4" />
                  {savingBank ? 'Saving...' : 'Save Bank Details'}
                </button>
              </form>
            </div>

            {/* Password section */}
            <div className="glass-card p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-surface-400" />
                  <h3 className="font-display font-bold text-gray-900">Password</h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowChangePw((v) => !v);
                    setPwForm({ current: '', newPw: '', confirm: '' });
                    setShowCurrent(false);
                    setShowNew(false);
                  }}
                  className={`btn-secondary text-sm ${showChangePw ? 'bg-surface-100' : ''}`}
                >
                  <KeyRound className="h-4 w-4" />
                  {showChangePw ? 'Cancel' : 'Change Password'}
                </button>
              </div>

              {!showChangePw && (
                <p className="mt-3 text-sm text-surface-400">
                  Keep your account secure by using a strong, unique password.
                </p>
              )}

              {showChangePw && (
                <form onSubmit={handleChangePassword} className="mt-5 space-y-4">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Current Password
                    </label>
                    <div className="relative">
                      <input
                        type={showCurrent ? 'text' : 'password'}
                        value={pwForm.current}
                        onChange={(e) => setPwForm((p) => ({ ...p, current: e.target.value }))}
                        className="input-field pr-11"
                        required
                        autoComplete="current-password"
                        placeholder="Enter your current password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrent((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-surface-600"
                      >
                        {showCurrent ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                        New Password
                      </label>
                      <div className="relative">
                        <input
                          type={showNew ? 'text' : 'password'}
                          value={pwForm.newPw}
                          onChange={(e) => setPwForm((p) => ({ ...p, newPw: e.target.value }))}
                          className="input-field pr-11"
                          minLength={6}
                          required
                          autoComplete="new-password"
                          placeholder="Min 6 characters"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNew((v) => !v)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-surface-600"
                        >
                          {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                        Confirm Password
                      </label>
                      <input
                        type="password"
                        value={pwForm.confirm}
                        onChange={(e) => setPwForm((p) => ({ ...p, confirm: e.target.value }))}
                        className="input-field"
                        required
                        autoComplete="new-password"
                        placeholder="Re-enter new password"
                      />
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button type="submit" disabled={savingPw} className="btn-primary">
                      <KeyRound className="h-4 w-4" />
                      {savingPw ? 'Changing...' : 'Change Password'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowChangePw(false)}
                      className="btn-secondary text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Recent attendance */}
            <div className="glass-card p-6">
              <h3 className="mb-4 font-display font-bold text-gray-900">Recent Attendance</h3>
              {recentAttendance.length === 0 ? (
                <p className="text-sm text-surface-400">No attendance records found for this month.</p>
              ) : (
                <div className="space-y-2">
                  {recentAttendance.map((record) => (
                    <div
                      key={record._id}
                      className="flex items-center justify-between rounded-xl px-3 py-2.5 hover:bg-surface-50"
                    >
                      <div className="flex items-center gap-3">
                        <CalendarCheck className="h-4 w-4 text-surface-400" />
                        <span className="text-sm text-gray-900">{formatDate(record.date)}</span>
                        {record.checkIn && (
                          <span className="text-xs text-surface-500">In {record.checkIn}</span>
                        )}
                        {record.checkOut && (
                          <span className="text-xs text-surface-500">Out {record.checkOut}</span>
                        )}
                      </div>
                      <span className={`status-badge text-xs ${getStatusTone(record.status)}`}>
                        {record.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
