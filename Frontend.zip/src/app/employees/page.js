﻿// 'use client';

// import { useEffect, useState } from 'react';
// import toast from 'react-hot-toast';
// import {
//   Edit2,
//   Mail,
//   Phone,
//   Plus,
//   Search,
//   Shield,
//   Trash2,
//   UserPlus,
//   Users,
//   X,
// } from 'lucide-react';
// import AppShell from '@/components/AppShell';
// import EmptyState from '@/components/EmptyState';
// import PageHeader from '@/components/PageHeader';
// import StatCard from '@/components/StatCard';
// import { employeeAPI } from '@/lib/api';
// import { formatCurrency, formatDate, getInitials, getStatusTone, toIsoDate } from '@/lib/utils';

// const EMPTY_FORM = {
//   employeeId: '',
//   name: '',
//   email: '',
//   password: '',
//   role: 'employee',
//   department: '',
//   designation: '',
//   salary: '',
//   phone: '',
//   doj: toIsoDate(new Date()),
//   fingerprintId: '',
//   leaveBalance: '12',
//   profilePic: '',
//   isActive: true,
// };

// export default function EmployeesPage() {
//   const [loading, setLoading] = useState(true);
//   const [saving, setSaving] = useState(false);
//   const [employees, setEmployees] = useState([]);
//   const [departments, setDepartments] = useState([]);
//   const [stats, setStats] = useState(null);
//   const [search, setSearch] = useState('');
//   const [department, setDepartment] = useState('');
//   const [role, setRole] = useState('');
//   const [status, setStatus] = useState('');
//   const [showForm, setShowForm] = useState(false);
//   const [editEmployee, setEditEmployee] = useState(null);
//   const [form, setForm] = useState(EMPTY_FORM);
//   const [deactivateId, setDeactivateId] = useState('');

//   // Debounce the search so we don't fire a request on every keystroke.
//   useEffect(() => {
//     const timer = setTimeout(() => {
//       loadEmployees();
//     }, search ? 350 : 0);
//     return () => clearTimeout(timer);
//   }, [search, department, role, status]);

//   useEffect(() => {
//     loadMeta();
//   }, []);

//   const loadMeta = async () => {
//     try {
//       const [departmentsRes, statsRes] = await Promise.all([employeeAPI.departments(), employeeAPI.stats()]);
//       setDepartments(departmentsRes.data.departments);
//       setStats(statsRes.data);
//     } catch {
//       toast.error('Failed to load employee metadata.');
//     }
//   };

//   const loadEmployees = async () => {
//     setLoading(true);
//     try {
//       const params = { limit: 100 };
//       if (search.trim()) params.search = search.trim();
//       if (department) params.department = department;
//       if (role) params.role = role;
//       if (status) params.isActive = status === 'active';

//       const { data } = await employeeAPI.list(params);
//       setEmployees(data.employees);
//     } catch (error) {
//       toast.error(error.response?.data?.message || 'Failed to load employees.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const openCreate = () => {
//     setEditEmployee(null);
//     setForm(EMPTY_FORM);
//     setShowForm(true);
//   };

//   const openEdit = (employee) => {
//     setEditEmployee(employee);
//     setForm({
//       employeeId: employee.employeeId || '',
//       name: employee.name || '',
//       email: employee.email || '',
//       password: '',
//       role: employee.role || 'employee',
//       department: employee.department || '',
//       designation: employee.designation || employee.position || '',
//       salary: String(employee.salary ?? ''),
//       phone: employee.phone || '',
//       doj: employee.doj ? toIsoDate(employee.doj) : toIsoDate(new Date()),
//       fingerprintId: employee.fingerprintId ?? '',
//       leaveBalance: String(employee.leaveBalance ?? 12),
//       profilePic: employee.profilePic || employee.avatar || '',
//       isActive: employee.isActive !== false,
//     });
//     setShowForm(true);
//   };

//   const handleSubmit = async (event) => {
//     event.preventDefault();
//     setSaving(true);

//     try {
//       const payload = {
//         employeeId: form.employeeId || undefined,
//         name: form.name.trim(),
//         email: form.email.trim(),
//         password: form.password || undefined,
//         role: form.role,
//         department: form.department.trim(),
//         designation: form.designation.trim(),
//         position: form.designation.trim(),
//         salary: Number(form.salary || 0),
//         phone: form.phone.trim(),
//         doj: form.doj || undefined,
//         fingerprintId: form.fingerprintId === '' ? '' : Number(form.fingerprintId),
//         leaveBalance: Number(form.leaveBalance || 0),
//         profilePic: form.profilePic.trim(),
//         avatar: form.profilePic.trim(),
//         isActive: Boolean(form.isActive),
//       };

//       if (editEmployee) {
//         await employeeAPI.update(editEmployee._id, payload);
//         toast.success('Employee updated successfully.');
//       } else {
//         await employeeAPI.create(payload);
//         toast.success('Employee created successfully.');
//       }

//       setShowForm(false);
//       setForm(EMPTY_FORM);
//       await Promise.all([loadEmployees(), loadMeta()]);
//     } catch (error) {
//       toast.error(error.response?.data?.message || 'Failed to save employee.');
//     } finally {
//       setSaving(false);
//     }
//   };

//   const handleDeactivate = async () => {
//     try {
//       await employeeAPI.delete(deactivateId);
//       toast.success('Employee deactivated successfully.');
//       setDeactivateId('');
//       await Promise.all([loadEmployees(), loadMeta()]);
//     } catch (error) {
//       toast.error(error.response?.data?.message || 'Failed to deactivate employee.');
//     }
//   };

//   return (
//     <AppShell requiredRole="hr">
//       <div className="mx-auto max-w-7xl space-y-6">
//         <PageHeader
//           title="Employee Directory"
//           description="Create, update, and manage employee records aligned with the HRMS workflow."
//           actions={[
//             <button key="create" type="button" onClick={openCreate} className="btn-primary text-sm">
//               <UserPlus className="h-4 w-4" />
//               Add Employee
//             </button>,
//           ]}
//         />

//         <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
//           <StatCard
//             icon={Users}
//             label="Employees"
//             value={stats?.totalEmployees ?? 0}
//             tone="bg-brand-100 text-brand-700"
//             subtext={`${stats?.activeEmployees ?? 0} active profiles`}
//           />
//           <StatCard
//             icon={Shield}
//             label="HR Admins"
//             value={employees.filter((employee) => employee.role === 'hr').length}
//             tone="bg-purple-100 text-purple-700"
//             subtext="Currently visible in this directory"
//           />
//           <StatCard
//             icon={Mail}
//             label="Departments"
//             value={stats?.totalDepartments ?? 0}
//             tone="bg-blue-100 text-blue-700"
//             subtext="Across the organization"
//           />
//           <StatCard
//             icon={Phone}
//             label="Inactive Profiles"
//             value={stats?.inactiveEmployees ?? 0}
//             tone="bg-red-100 text-red-700"
//             subtext="Can be reactivated from edit form"
//           />
//         </div>

//         <div className="glass-card p-4">
//           <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_180px_160px_160px]">
//             <div className="relative">
//               <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-surface-400" />
//               <input
//                 type="text"
//                 value={search}
//                 onChange={(event) => setSearch(event.target.value)}
//                 placeholder="Search by employee ID, name, email, or department"
//                 className="input-field pl-10"
//               />
//             </div>
//             <select value={department} onChange={(event) => setDepartment(event.target.value)} className="input-field">
//               <option value="">All Departments</option>
//               {departments.map((item) => (
//                 <option key={item} value={item}>
//                   {item}
//                 </option>
//               ))}
//             </select>
//             <select value={role} onChange={(event) => setRole(event.target.value)} className="input-field">
//               <option value="">All Roles</option>
//               <option value="employee">Employee</option>
//               <option value="hr">HR</option>
//             </select>
//             <select value={status} onChange={(event) => setStatus(event.target.value)} className="input-field">
//               <option value="">All Statuses</option>
//               <option value="active">Active</option>
//               <option value="inactive">Inactive</option>
//             </select>
//           </div>
//         </div>

//         <div className="glass-card overflow-hidden">
//           {loading ? (
//             <div className="p-10 text-center text-sm text-surface-400">Loading employee records...</div>
//           ) : employees.length === 0 ? (
//             <EmptyState
//               icon={Users}
//               title="No employees found"
//               description="Try adjusting your filters or create a new employee profile."
//               action={
//                 <button type="button" onClick={openCreate} className="btn-primary text-sm">
//                   <Plus className="h-4 w-4" />
//                   Create Employee
//                 </button>
//               }
//             />
//           ) : (
//             <div className="overflow-x-auto">
//               <table className="w-full min-w-[1040px]">
//                 <thead>
//                   <tr className="border-b border-surface-200 bg-surface-50">
//                     {['Employee', 'Department', 'Designation', 'Salary', 'Leave', 'Joined', 'Status', 'Actions'].map((heading) => (
//                       <th key={heading} className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider text-surface-500 ${heading === 'Actions' ? 'text-right' : 'text-left'}`}>
//                         {heading}
//                       </th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody className="divide-y divide-surface-100">
//                   {employees.map((employee) => (
//                     <tr key={employee._id} className="hover:bg-surface-50/80">
//                       <td className="px-5 py-4">
//                         <div className="flex items-center gap-3">
//                           <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-100 text-brand-700">
//                             <span className="text-sm font-bold">{getInitials(employee.name)}</span>
//                           </div>
//                           <div>
//                             <p className="text-sm font-semibold text-gray-900">{employee.name}</p>
//                             <p className="text-xs text-surface-400">
//                               {employee.employeeId || 'Auto ID'} • {employee.email}
//                             </p>
//                             {employee.phone ? <p className="text-xs text-surface-400">{employee.phone}</p> : null}
//                           </div>
//                         </div>
//                       </td>
//                       <td className="px-5 py-4 text-sm text-gray-700">{employee.department || '-'}</td>
//                       <td className="px-5 py-4 text-sm text-gray-700">{employee.designation || employee.position || '-'}</td>
//                       <td className="px-5 py-4 text-sm font-semibold text-gray-900">{formatCurrency(employee.salary)}</td>
//                       <td className="px-5 py-4 text-sm text-gray-700">{employee.leaveBalance ?? 0} days</td>
//                       <td className="px-5 py-4 text-sm text-gray-700">{formatDate(employee.doj)}</td>
//                       <td className="px-5 py-4">
//                         <div className="flex flex-wrap gap-2">
//                           <span className={`status-badge ${getStatusTone(employee.isActive ? 'active' : 'inactive')}`}>
//                             {employee.isActive ? 'Active' : 'Inactive'}
//                           </span>
//                           <span className={`status-badge ${employee.role === 'hr' ? 'bg-purple-100 text-purple-700' : 'bg-surface-100 text-surface-500'}`}>
//                             {employee.role}
//                           </span>
//                         </div>
//                       </td>
//                       <td className="px-5 py-4 text-right">
//                         <div className="flex items-center justify-end gap-2">
//                           <button
//                             type="button"
//                             onClick={() => openEdit(employee)}
//                             className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-brand-200 hover:bg-brand-50 hover:text-brand-700"
//                             title="Edit employee"
//                           >
//                             <Edit2 className="h-4 w-4" />
//                           </button>
//                           {employee.isActive ? (
//                             <button
//                               type="button"
//                               onClick={() => setDeactivateId(employee._id)}
//                               className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
//                               title="Deactivate employee"
//                             >
//                               <Trash2 className="h-4 w-4" />
//                             </button>
//                           ) : null}
//                         </div>
//                       </td>
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//             </div>
//           )}
//         </div>
//       </div>

//       {showForm ? (
//         <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm" onClick={() => setShowForm(false)}>
//           <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-[28px] bg-white shadow-2xl" onClick={(event) => event.stopPropagation()}>
//             <div className="flex items-center justify-between border-b border-surface-200 px-6 py-5">
//               <div>
//                 <h3 className="font-display text-xl font-bold text-gray-900">
//                   {editEmployee ? 'Edit Employee' : 'Create Employee'}
//                 </h3>
//                 <p className="mt-1 text-sm text-surface-400">
//                   Keep the profile complete so payroll, attendance, and leave workflows stay accurate.
//                 </p>
//               </div>
//               <button type="button" onClick={() => setShowForm(false)} className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500">
//                 <X className="h-4 w-4" />
//               </button>
//             </div>

//             <form onSubmit={handleSubmit} className="space-y-5 px-6 py-6">
//               <div className="grid gap-4 md:grid-cols-2">
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Employee ID</label>
//                   <input
//                     type="text"
//                     value={form.employeeId}
//                     onChange={(event) => setForm({ ...form, employeeId: event.target.value.toUpperCase() })}
//                     placeholder="Leave blank to auto-generate"
//                     className="input-field"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Role</label>
//                   <select value={form.role} onChange={(event) => setForm({ ...form, role: event.target.value })} className="input-field">
//                     <option value="employee">Employee</option>
//                     <option value="hr">HR</option>
//                   </select>
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Full Name</label>
//                   <input
//                     type="text"
//                     value={form.name}
//                     onChange={(event) => setForm({ ...form, name: event.target.value })}
//                     className="input-field"
//                     required
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Email</label>
//                   <input
//                     type="email"
//                     value={form.email}
//                     onChange={(event) => setForm({ ...form, email: event.target.value })}
//                     className="input-field"
//                     required
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
//                     {editEmployee ? 'Reset Password' : 'Password'}
//                   </label>
//                   <input
//                     type="password"
//                     value={form.password}
//                     onChange={(event) => setForm({ ...form, password: event.target.value })}
//                     placeholder={editEmployee ? 'Leave blank to keep current password' : 'Defaults to changeme123'}
//                     className="input-field"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Department</label>
//                   <input
//                     type="text"
//                     value={form.department}
//                     onChange={(event) => setForm({ ...form, department: event.target.value })}
//                     className="input-field"
//                     placeholder="Engineering"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Designation</label>
//                   <input
//                     type="text"
//                     value={form.designation}
//                     onChange={(event) => setForm({ ...form, designation: event.target.value })}
//                     className="input-field"
//                     placeholder="Software Engineer"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Monthly Salary</label>
//                   <input
//                     type="number"
//                     min="0"
//                     value={form.salary}
//                     onChange={(event) => setForm({ ...form, salary: event.target.value })}
//                     className="input-field"
//                     placeholder="35000"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Phone</label>
//                   <input
//                     type="text"
//                     value={form.phone}
//                     onChange={(event) => setForm({ ...form, phone: event.target.value })}
//                     className="input-field"
//                     placeholder="+91 9876543210"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Date of Joining</label>
//                   <input
//                     type="date"
//                     value={form.doj}
//                     onChange={(event) => setForm({ ...form, doj: event.target.value })}
//                     className="input-field"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Fingerprint ID</label>
//                   <input
//                     type="number"
//                     min="0"
//                     value={form.fingerprintId}
//                     onChange={(event) => setForm({ ...form, fingerprintId: event.target.value })}
//                     className="input-field"
//                     placeholder="Matches biometric export code"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Leave Balance</label>
//                   <input
//                     type="number"
//                     min="0"
//                     step="0.5"
//                     value={form.leaveBalance}
//                     onChange={(event) => setForm({ ...form, leaveBalance: event.target.value })}
//                     className="input-field"
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Profile Image URL</label>
//                   <input
//                     type="url"
//                     value={form.profilePic}
//                     onChange={(event) => setForm({ ...form, profilePic: event.target.value })}
//                     className="input-field"
//                     placeholder="https://..."
//                   />
//                 </div>
//                 <div>
//                   <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">Profile Status</label>
//                   <select
//                     value={form.isActive ? 'active' : 'inactive'}
//                     onChange={(event) => setForm({ ...form, isActive: event.target.value === 'active' })}
//                     className="input-field"
//                   >
//                     <option value="active">Active</option>
//                     <option value="inactive">Inactive</option>
//                   </select>
//                 </div>
//               </div>

//               {!editEmployee ? (
//                 <p className="rounded-2xl bg-brand-50 p-4 text-sm text-brand-700">
//                   If no password is entered, the account will be created with the default password <span className="font-semibold">changeme123</span>.
//                 </p>
//               ) : null}

//               <div className="flex justify-end gap-3">
//                 <button type="button" onClick={() => setShowForm(false)} className="btn-secondary text-sm">
//                   Cancel
//                 </button>
//                 <button type="submit" disabled={saving} className="btn-primary text-sm">
//                   {saving ? 'Saving...' : editEmployee ? 'Update Employee' : 'Create Employee'}
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       ) : null}

//       {deactivateId ? (
//         <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm" onClick={() => setDeactivateId('')}>
//           <div className="w-full max-w-md rounded-[28px] bg-white p-6 shadow-2xl" onClick={(event) => event.stopPropagation()}>
//             <h3 className="font-display text-xl font-bold text-gray-900">Deactivate Employee</h3>
//             <p className="mt-2 text-sm leading-6 text-surface-500">
//               This keeps attendance and payroll history intact while removing the employee from active operations.
//             </p>
//             <div className="mt-6 flex justify-end gap-3">
//               <button type="button" onClick={() => setDeactivateId('')} className="btn-secondary text-sm">
//                 Cancel
//               </button>
//               <button type="button" onClick={handleDeactivate} className="btn-danger text-sm">
//                 Deactivate
//               </button>
//             </div>
//           </div>
//         </div>
//       ) : null}
//     </AppShell>
//   );
// }

"use client";

import { useEffect, useRef, useState } from "react";
import toast from "react-hot-toast";
import {
  AlertCircle,
  Briefcase,
  Building2,
  CalendarDays,
  CheckCircle2,
  CreditCard,
  Download,
  Edit2,
  Eye,
  EyeOff,
  FileSpreadsheet,
  Fingerprint,
  KeyRound,
  Mail,
  Phone,
  Plus,
  Search,
  Shield,
  Trash2,
  Upload,
  UserCircle,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import AppShell from "@/components/AppShell";
import EmptyState from "@/components/EmptyState";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import { employeeAPI } from "@/lib/api";
import {
  formatCurrency,
  formatDate,
  getInitials,
  getStatusTone,
  toIsoDate,
} from "@/lib/utils";

const EMPTY_FORM = {
  employeeId: "",
  name: "",
  email: "",
  password: "",
  role: "employee",
  department: "",
  designation: "",
  salary: "",
  phone: "",
  doj: toIsoDate(new Date()),
  fingerprintId: "",
  leaveBalance: "12",
  profilePic: "",
  isActive: true,
  bankName: "",
  bankAccountNo: "",
  confirmAccountNo: "",
  ifscCode: "",
  branchName: "",
};

// ── Client-side Excel preview parser ─────────────────────────────────────────
async function parseExcelPreview(file) {
  const XLSX = await import("xlsx");
  const lib = XLSX.default || XLSX;
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = lib.read(new Uint8Array(e.target.result), { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rawRows = lib.utils.sheet_to_json(sheet, {
          header: 1,
          defval: "",
          raw: false,
        });

        let headerIdx = -1,
          headers = [];
        for (let i = 0; i < rawRows.length; i++) {
          const joined = rawRows[i]
            .map((c) =>
              String(c || "")
                .toLowerCase()
                .trim(),
            )
            .join("|");
          if (
            joined.includes("name") &&
            (joined.includes("employee code") ||
              joined.includes("card no") ||
              joined.includes("department"))
          ) {
            headerIdx = i;
            headers = rawRows[i].map((c) =>
              String(c || "")
                .toLowerCase()
                .trim(),
            );
            break;
          }
        }
        if (headerIdx === -1) {
          return reject(
            new Error(
              "Header row not found. Expected columns: Employee Code, Card No, Name, Department, Designation, Joining Date.",
            ),
          );
        }

        const col = (aliases) => {
          const i = headers.findIndex((h) => aliases.includes(h));
          return i >= 0 ? i : null;
        };
        const m = {
          empCode: col(["employee code", "emp code", "empcode"]),
          cardNo: col(["card no", "card number", "cardno"]),
          name: col(["name", "emp name", "employee name"]),
          loc: col(["branch/location", "location", "branch"]),
          dept: col(["department", "dept"]),
          desig: col(["designation", "position"]),
          doj: col(["joining date", "date of joining", "doj"]),
          empType: col(["employment type", "emp type", "type"]),
        };
        const get = (row, idx) =>
          idx !== null ? String(row[idx] || "").trim() : "";
        const rows = rawRows
          .slice(headerIdx + 1)
          .map((r) => ({
            empCode: get(r, m.empCode),
            cardNo: get(r, m.cardNo),
            name: get(r, m.name),
            location: get(r, m.loc) || get(r, m.dept),
            department: get(r, m.dept),
            designation: get(r, m.desig),
            doj: get(r, m.doj),
            empType: get(r, m.empType),
          }))
          .filter((r) => r.name);
        resolve(rows);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error("Failed to read file."));
    reader.readAsArrayBuffer(file);
  });
}

function downloadTemplate() {
  import("xlsx").then((mod) => {
    const lib = mod.default || mod;
    const header = ["Employee Information", ...Array(15).fill("")];
    const colsRow = [
      "Employee Code",
      "Card No",
      "Name",
      "Father's Name",
      "Branch/Location",
      "Department",
      "Designation",
      "Group",
      "Birth Date",
      "Joining Date",
      "Gender",
      "Employment Type",
      "Aadhar No",
      "PAN No",
      "DL No",
      "Address",
    ];
    const sample = [
      [
        "1",
        "1",
        "Aditya Kore",
        "",
        "Delhi",
        "Human Resource",
        "HR",
        "Emp Group",
        "01/01/1995",
        "13/03/2026",
        "Male",
        "Permanent",
        "",
        "",
        "",
        "",
      ],
      [
        "2",
        "2",
        "Nihal Wasnik",
        "",
        "Delhi",
        "Business Development",
        "BDE",
        "Emp Group",
        "15/06/1998",
        "13/03/2026",
        "Male",
        "Permanent",
        "",
        "",
        "",
        "",
      ],
    ];
    const ws = lib.utils.aoa_to_sheet([header, colsRow, ...sample]);
    const wb = lib.utils.book_new();
    lib.utils.book_append_sheet(wb, ws, "Sheet1");
    lib.writeFile(wb, "employee_import_template.xlsx");
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
export default function EmployeesPage() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [stats, setStats] = useState(null);
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("");
  const [role, setRole] = useState("");
  const [status, setStatus] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editEmployee, setEditEmployee] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [deactivateId, setDeactivateId] = useState("");

  // password visibility toggles per employee row (key: employeeId)
  const [visiblePwIds, setVisiblePwIds] = useState({});

  // reset-password modal
  const [resetPwTarget, setResetPwTarget] = useState(null); // employee object
  const [resetPwValue, setResetPwValue] = useState("");
  const [resetPwConfirm, setResetPwConfirm] = useState("");
  const [resetPwShow, setResetPwShow] = useState(false);
  const [resetPwSaving, setResetPwSaving] = useState(false);

  // view-profile modal
  const [viewEmployee, setViewEmployee] = useState(null);
  const [showViewPw, setShowViewPw] = useState(false);

  // bulk import
  const [importModal, setImportModal] = useState(false);
  const [importFile, setImportFile] = useState(null);
  const [importRows, setImportRows] = useState(null);
  const [importParseErr, setImportParseErr] = useState("");
  const [importParsing, setImportParsing] = useState(false);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => loadEmployees(), search ? 350 : 0);
    return () => clearTimeout(t);
  }, [search, department, role, status]);

  useEffect(() => {
    loadMeta();
  }, []);

  const loadMeta = async () => {
    try {
      const [dr, sr] = await Promise.all([
        employeeAPI.departments(),
        employeeAPI.stats(),
      ]);
      setDepartments(dr.data.departments);
      setStats(sr.data);
    } catch {
      toast.error("Failed to load metadata.");
    }
  };

  const loadEmployees = async () => {
    setLoading(true);
    try {
      const params = { limit: 100 };
      if (search.trim()) params.search = search.trim();
      if (department) params.department = department;
      if (role) params.role = role;
      if (status) params.isActive = status === "active";
      const { data } = await employeeAPI.list(params);
      setEmployees(data.employees);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to load employees.");
    } finally {
      setLoading(false);
    }
  };

  const openCreate = () => {
    setEditEmployee(null);
    setForm(EMPTY_FORM);
    setShowForm(true);
  };
  const openEdit = (emp) => {
    setEditEmployee(emp);
    setForm({
      employeeId: emp.employeeId || "",
      name: emp.name || "",
      email: emp.email || "",
      password: "",
      role: emp.role || "employee",
      department: emp.department || "",
      designation: emp.designation || emp.position || "",
      salary: String(emp.salary ?? ""),
      phone: emp.phone || "",
      doj: emp.doj ? toIsoDate(emp.doj) : toIsoDate(new Date()),
      fingerprintId: emp.fingerprintId ?? "",
      leaveBalance: String(emp.leaveBalance ?? 12),
      profilePic: emp.profilePic || emp.avatar || "",
      isActive: emp.isActive !== false,
      bankName: emp.bankName || "",
      bankAccountNo: emp.bankAccountNo || "",
      confirmAccountNo: emp.bankAccountNo || "",
      ifscCode: emp.ifscCode || "",
      branchName: emp.branchName || "",
    });
    setShowForm(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editEmployee && form.bankAccountNo !== form.confirmAccountNo) {
        toast.error("Bank account numbers do not match.");
        setSaving(false);
        return;
      }
      const p = {
        employeeId: form.employeeId || undefined,
        name: form.name.trim(),
        email: form.email.trim(),
        password: form.password || undefined,
        role: form.role,
        department: form.department.trim(),
        designation: form.designation.trim(),
        position: form.designation.trim(),
        salary: Number(form.salary || 0),
        phone: form.phone.trim(),
        doj: form.doj || undefined,
        fingerprintId:
          form.fingerprintId === "" ? "" : Number(form.fingerprintId),
        leaveBalance: Number(form.leaveBalance || 0),
        profilePic: form.profilePic.trim(),
        avatar: form.profilePic.trim(),
        isActive: Boolean(form.isActive),
        bankName: form.bankName.trim(),
        bankAccountNo: form.bankAccountNo.trim(),
        ifscCode: form.ifscCode.trim().toUpperCase(),
        branchName: form.branchName.trim(),
      };
      if (editEmployee) {
        await employeeAPI.update(editEmployee._id, p);
        toast.success("Employee updated.");
      } else {
        await employeeAPI.create(p);
        toast.success("Employee created.");
      }
      setShowForm(false);
      setForm(EMPTY_FORM);
      await Promise.all([loadEmployees(), loadMeta()]);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to save.");
    } finally {
      setSaving(false);
    }
  };

  const handleDeactivate = async () => {
    try {
      await employeeAPI.delete(deactivateId);
      toast.success("Employee deactivated.");
      setDeactivateId("");
      await Promise.all([loadEmployees(), loadMeta()]);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to deactivate.");
    }
  };

  const openResetPw = (emp) => {
    setResetPwTarget(emp);
    setResetPwValue("");
    setResetPwConfirm("");
    setResetPwShow(false);
  };

  const openView = (emp) => {
    setViewEmployee(emp);
    setShowViewPw(false);
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    if (resetPwValue.length < 6) {
      toast.error("Password must be at least 6 characters.");
      return;
    }
    if (resetPwValue !== resetPwConfirm) {
      toast.error("Passwords do not match.");
      return;
    }
    setResetPwSaving(true);
    try {
      await employeeAPI.resetPassword(resetPwTarget._id, resetPwValue);
      toast.success(`Password reset for ${resetPwTarget.name}.`);
      // Update local state so the new tempPassword shows inline without a full reload.
      setEmployees((prev) =>
        prev.map((emp) =>
          emp._id === resetPwTarget._id
            ? { ...emp, tempPassword: resetPwValue }
            : emp,
        ),
      );
      setResetPwTarget(null);
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to reset password.");
    } finally {
      setResetPwSaving(false);
    }
  };

  const openImport = () => {
    setImportFile(null);
    setImportRows(null);
    setImportParseErr("");
    setImportResult(null);
    setImportModal(true);
  };

  const handleFileChange = async (file) => {
    if (!file) return;
    setImportFile(file);
    setImportRows(null);
    setImportParseErr("");
    setImportResult(null);
    setImportParsing(true);
    try {
      const rows = await parseExcelPreview(file);
      setImportRows(rows);
    } catch (err) {
      setImportParseErr(err.message);
    } finally {
      setImportParsing(false);
    }
  };

  const handleBulkImport = async () => {
    if (!importFile || !importRows) return;
    setImporting(true);
    setImportResult(null);
    try {
      const { data } = await employeeAPI.bulkUpload(importFile);
      setImportResult(data);
      if (data.created > 0) {
        toast.success(`${data.created} employees imported.`);
        await Promise.all([loadEmployees(), loadMeta()]);
      } else {
        toast(
          "No new employees created — all rows were already in the system.",
          { icon: "ℹ️" },
        );
      }
    } catch (err) {
      toast.error(err.response?.data?.message || "Import failed.");
    } finally {
      setImporting(false);
    }
  };

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <AppShell requiredRole="hr">
      <div className="mx-auto max-w-7xl space-y-6">
        <PageHeader
          title="Employee Directory"
          description="Create, update, and manage employee records aligned with the HRMS workflow."
          actions={[
            <button
              key="import"
              type="button"
              onClick={openImport}
              className="btn-secondary text-sm"
            >
              <FileSpreadsheet className="h-4 w-4" />
              Import Excel
            </button>,
            <button
              key="create"
              type="button"
              onClick={openCreate}
              className="btn-primary text-sm"
            >
              <UserPlus className="h-4 w-4" />
              Add Employee
            </button>,
          ]}
        />

        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            icon={Users}
            label="Employees"
            value={stats?.totalEmployees ?? 0}
            tone="bg-brand-100 text-brand-700"
            subtext={`${stats?.activeEmployees ?? 0} active`}
          />
          <StatCard
            icon={Shield}
            label="HR Admins"
            value={employees.filter((e) => e.role === "hr").length}
            tone="bg-purple-100 text-purple-700"
            subtext="Visible in directory"
          />
          <StatCard
            icon={Mail}
            label="Departments"
            value={stats?.totalDepartments ?? 0}
            tone="bg-blue-100 text-blue-700"
            subtext="Across organization"
          />
          <StatCard
            icon={Phone}
            label="Inactive Profiles"
            value={stats?.inactiveEmployees ?? 0}
            tone="bg-red-100 text-red-700"
            subtext="Re-activate via edit"
          />
        </div>

        {/* Filters */}
        <div className="glass-card p-4">
          <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_180px_160px_160px]">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-surface-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by ID, name, email, or department"
                className="input-field pl-10"
              />
            </div>
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="input-field"
            >
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="input-field"
            >
              <option value="">All Roles</option>
              <option value="employee">Employee</option>
              <option value="hr">HR</option>
            </select>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="input-field"
            >
              <option value="">All Statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="glass-card overflow-hidden">
          {loading ? (
            <div className="p-10 text-center text-sm text-surface-400">
              Loading employee records…
            </div>
          ) : employees.length === 0 ? (
            <EmptyState
              icon={Users}
              title="No employees found"
              description="Try adjusting your filters or create a new employee profile."
              action={
                <button
                  type="button"
                  onClick={openCreate}
                  className="btn-primary text-sm"
                >
                  <Plus className="h-4 w-4" />
                  Create Employee
                </button>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1040px]">
                <thead>
                  <tr className="border-b border-surface-200 bg-surface-50">
                    {[
                      "Employee",
                      "Department",
                      "Designation",
                      "Salary",
                      "Leave",
                      "Joined",
                      "Password",
                      "Status",
                      "Actions",
                    ].map((h) => (
                      <th
                        key={h}
                        className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider text-surface-500 ${h === "Actions" ? "text-right" : "text-left"}`}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-100">
                  {employees.map((emp) => (
                    <tr key={emp._id} className="hover:bg-surface-50/80">
                      <td className="px-5 py-4">
                        <button
                          type="button"
                          onClick={() => openView(emp)}
                          className="flex items-center gap-3 text-left hover:opacity-80 transition-opacity"
                          title="View profile"
                        >
                          <div className="relative flex-shrink-0">
                            {emp.avatar || emp.profilePic ? (
                              <img
                                src={emp.avatar || emp.profilePic}
                                alt={emp.name}
                                className="h-11 w-11 rounded-2xl object-cover"
                              />
                            ) : (
                              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-100 text-brand-700">
                                <span className="text-sm font-bold">
                                  {getInitials(emp.name)}
                                </span>
                              </div>
                            )}
                          </div>
                          <div>
                            <p className="text-sm font-semibold text-gray-900">
                              {emp.name}
                            </p>
                            <p className="text-xs text-surface-400">
                              {emp.employeeId || "Auto ID"} • {emp.email}
                            </p>
                            {emp.phone && (
                              <p className="text-xs text-surface-400">
                                {emp.phone}
                              </p>
                            )}
                          </div>
                        </button>
                      </td>
                      <td className="px-5 py-4 text-sm text-gray-700">
                        {emp.department || "-"}
                      </td>
                      <td className="px-5 py-4 text-sm text-gray-700">
                        {emp.designation || emp.position || "-"}
                      </td>
                      <td className="px-5 py-4 text-sm font-semibold text-gray-900">
                        {formatCurrency(emp.salary)}
                      </td>
                      <td className="px-5 py-4 text-sm text-gray-700">
                        {emp.leaveBalance ?? 0} days
                      </td>
                      <td className="px-5 py-4 text-sm text-gray-700">
                        {formatDate(emp.doj)}
                      </td>

                      {/* Password column */}
                      <td className="px-5 py-4">
                        {emp.tempPassword ? (
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-sm text-gray-900">
                              {visiblePwIds[emp._id]
                                ? emp.tempPassword
                                : '•'.repeat(Math.min(emp.tempPassword.length, 10))}
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                setVisiblePwIds((prev) => ({
                                  ...prev,
                                  [emp._id]: !prev[emp._id],
                                }))
                              }
                              className="text-surface-400 hover:text-brand-700"
                              title={visiblePwIds[emp._id] ? 'Hide' : 'Show'}
                            >
                              {visiblePwIds[emp._id]
                                ? <EyeOff className="h-3.5 w-3.5" />
                                : <Eye className="h-3.5 w-3.5" />}
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs italic text-surface-400">Changed by user</span>
                        )}
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex flex-wrap gap-2">
                          <span
                            className={`status-badge ${getStatusTone(emp.isActive ? "active" : "inactive")}`}
                          >
                            {emp.isActive ? "Active" : "Inactive"}
                          </span>
                          <span
                            className={`status-badge ${emp.role === "hr" ? "bg-purple-100 text-purple-700" : "bg-surface-100 text-surface-500"}`}
                          >
                            {emp.role}
                          </span>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => openView(emp)}
                            className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700"
                            title="View profile"
                          >
                            <UserCircle className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openEdit(emp)}
                            className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-brand-200 hover:bg-brand-50 hover:text-brand-700"
                            title="Edit employee"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openResetPw(emp)}
                            className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-amber-200 hover:bg-amber-50 hover:text-amber-700"
                            title="Reset password"
                          >
                            <KeyRound className="h-4 w-4" />
                          </button>
                          {emp.isActive && (
                            <button
                              type="button"
                              onClick={() => setDeactivateId(emp._id)}
                              className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                              title="Deactivate employee"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* ═══════════ SINGLE EMPLOYEE MODAL ═══════════ */}
      {showForm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
          onClick={() => setShowForm(false)}
        >
          <div
            className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-[28px] bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-surface-200 px-6 py-5">
              <div>
                <h3 className="font-display text-xl font-bold text-gray-900">
                  {editEmployee ? "Edit Employee" : "Create Employee"}
                </h3>
                <p className="mt-1 text-sm text-surface-400">
                  Keep the profile complete so payroll, attendance, and leave
                  workflows stay accurate.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-5 px-6 py-6">
              <div className="grid gap-4 md:grid-cols-2">
                {[
                  {
                    label: "Employee ID",
                    field: "employeeId",
                    type: "text",
                    placeholder: "Leave blank to auto-generate",
                    transform: (v) => v.toUpperCase(),
                  },
                  {
                    label: "Full Name",
                    field: "name",
                    type: "text",
                    required: true,
                  },
                  {
                    label: "Email",
                    field: "email",
                    type: "email",
                    required: true,
                  },
                  {
                    label: editEmployee ? "Reset Password" : "Password",
                    field: "password",
                    type: "password",
                    placeholder: editEmployee
                      ? "Leave blank to keep current"
                      : "Defaults to changeme123",
                  },
                  {
                    label: "Department",
                    field: "department",
                    type: "text",
                    placeholder: "Engineering",
                  },
                  {
                    label: "Designation",
                    field: "designation",
                    type: "text",
                    placeholder: "Software Engineer",
                  },
                  {
                    label: "Monthly Salary",
                    field: "salary",
                    type: "number",
                    placeholder: "35000",
                    min: 0,
                  },
                  {
                    label: "Phone",
                    field: "phone",
                    type: "text",
                    placeholder: "+91 9876543210",
                  },
                  { label: "Date of Joining", field: "doj", type: "date" },
                  {
                    label: "Fingerprint / Card ID",
                    field: "fingerprintId",
                    type: "number",
                    placeholder: "Matches biometric export code",
                    min: 0,
                  },
                  {
                    label: "Leave Balance",
                    field: "leaveBalance",
                    type: "number",
                    min: 0,
                    step: 0.5,
                  },
                  {
                    label: "Profile Image URL",
                    field: "profilePic",
                    type: "url",
                    placeholder: "https://…",
                  },
                ].map(
                  ({
                    label,
                    field,
                    type,
                    placeholder,
                    required,
                    min,
                    step,
                    transform,
                  }) => (
                    <div key={field}>
                      <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                        {label}
                      </label>
                      <input
                        type={type}
                        value={form[field]}
                        required={required}
                        min={min}
                        step={step}
                        placeholder={placeholder}
                        onChange={(e) =>
                          setForm({
                            ...form,
                            [field]: transform
                              ? transform(e.target.value)
                              : e.target.value,
                          })
                        }
                        className="input-field"
                      />
                    </div>
                  ),
                )}
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Role
                  </label>
                  <select
                    value={form.role}
                    onChange={(e) => setForm({ ...form, role: e.target.value })}
                    className="input-field"
                  >
                    <option value="employee">Employee</option>
                    <option value="hr">HR</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Profile Status
                  </label>
                  <select
                    value={form.isActive ? "active" : "inactive"}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        isActive: e.target.value === "active",
                      })
                    }
                    className="input-field"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>
              {/* Bank Details section */}
              <div className="border-t border-surface-100 pt-5">
                <div className="mb-3 flex items-center gap-2">
                  <CreditCard className="h-4 w-4 text-surface-400" />
                  <h4 className="text-sm font-semibold text-gray-700">Bank Details</h4>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Bank Name
                    </label>
                    <input
                      type="text"
                      value={form.bankName}
                      onChange={(e) => setForm({ ...form, bankName: e.target.value })}
                      className="input-field"
                      placeholder="e.g. State Bank of India"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Branch Name
                    </label>
                    <input
                      type="text"
                      value={form.branchName}
                      onChange={(e) => setForm({ ...form, branchName: e.target.value })}
                      className="input-field"
                      placeholder="e.g. Andheri West"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Account Number
                    </label>
                    <input
                      type="text"
                      value={form.bankAccountNo}
                      onChange={(e) => setForm({ ...form, bankAccountNo: e.target.value })}
                      className="input-field"
                      placeholder="Enter account number"
                      maxLength={20}
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      Confirm Account Number
                    </label>
                    <input
                      type="text"
                      value={form.confirmAccountNo}
                      onChange={(e) => setForm({ ...form, confirmAccountNo: e.target.value })}
                      className="input-field"
                      placeholder="Re-enter account number"
                      maxLength={20}
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                      IFSC Code
                    </label>
                    <input
                      type="text"
                      value={form.ifscCode}
                      onChange={(e) => setForm({ ...form, ifscCode: e.target.value.toUpperCase() })}
                      className="input-field font-mono"
                      placeholder="e.g. SBIN0001234"
                      maxLength={11}
                    />
                  </div>
                </div>
              </div>

              {!editEmployee && (
                <p className="rounded-2xl bg-brand-50 p-4 text-sm text-brand-700">
                  If no password is entered, the account defaults to{" "}
                  <span className="font-semibold">changeme123</span>.
                </p>
              )}
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="btn-secondary text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="btn-primary text-sm"
                >
                  {saving
                    ? "Saving…"
                    : editEmployee
                      ? "Update Employee"
                      : "Create Employee"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ═══════════ BULK IMPORT MODAL ═══════════ */}
      {importModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
          onClick={() => setImportModal(false)}
        >
          <div
            className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-[28px] bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-surface-200 px-6 py-5">
              <div>
                <h3 className="font-display text-xl font-bold text-gray-900">
                  Import Employees from Excel
                </h3>
                <p className="mt-1 text-sm text-surface-400">
                  Card No maps to Fingerprint ID for attendance matching. Emails
                  are auto-generated.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setImportModal(false)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-5 px-6 py-6">
              {/* Format guide */}
              <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm">
                <p className="mb-2 font-semibold text-blue-900">
                  Expected column headers
                </p>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs text-blue-800">
                  {[
                    ["Employee Code", "Sequential #"],
                    ["Card No", "→ Fingerprint ID"],
                    ["Name", "Required"],
                    ["Department", "Team name"],
                    ["Designation", "Job title"],
                    ["Joining Date", "DD/MM/YYYY"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex gap-1.5">
                      <span className="font-medium">{k}:</span>
                      <span className="text-blue-600">{v}</span>
                    </div>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={downloadTemplate}
                  className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-blue-100 px-3 py-1.5 text-xs font-semibold text-blue-800 hover:bg-blue-200 transition"
                >
                  <Download className="h-3.5 w-3.5" />
                  Download sample template
                </button>
              </div>

              {/* Drop zone */}
              <div
                className={`cursor-pointer rounded-2xl border-2 border-dashed p-8 text-center transition-all ${importFile ? "border-brand-400 bg-brand-50/40" : "border-surface-200 hover:border-brand-400 hover:bg-brand-50/20"}`}
                onClick={() => fileRef.current?.click()}
              >
                <input
                  ref={fileRef}
                  type="file"
                  accept=".xls,.xlsx,.csv"
                  className="hidden"
                  onChange={(e) => handleFileChange(e.target.files[0])}
                />
                {importFile ? (
                  <div className="flex items-center justify-center gap-3">
                    <FileSpreadsheet className="h-7 w-7 text-brand-600" />
                    <div className="text-left">
                      <p className="text-sm font-semibold text-gray-900">
                        {importFile.name}
                      </p>
                      <p className="text-xs text-surface-400">
                        {(importFile.size / 1024).toFixed(1)} KB — click to
                        change
                      </p>
                    </div>
                  </div>
                ) : (
                  <>
                    <Upload className="mx-auto mb-2 h-9 w-9 text-surface-300" />
                    <p className="text-sm font-medium text-surface-500">
                      Click to select your Excel / CSV file
                    </p>
                    <p className="mt-1 text-xs text-surface-300">
                      .xls · .xlsx · .csv — Max 10 MB
                    </p>
                  </>
                )}
              </div>

              {importParseErr && (
                <div className="flex gap-2 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">
                  <AlertCircle className="mt-0.5 h-4 w-4 flex-shrink-0" />
                  <span>{importParseErr}</span>
                </div>
              )}
              {importParsing && (
                <p className="text-center text-sm text-surface-400">
                  Parsing file…
                </p>
              )}

              {/* Preview */}
              {importRows && !importParsing && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-semibold text-gray-900">
                      {importRows.length} employee
                      {importRows.length !== 1 ? "s" : ""} detected
                    </p>
                    <span className="rounded-full bg-brand-100 px-2.5 py-1 text-xs font-medium text-brand-700">
                      Preview
                    </span>
                  </div>
                  <div className="overflow-x-auto rounded-xl border border-surface-200">
                    <table className="w-full min-w-[540px] text-xs">
                      <thead>
                        <tr className="border-b border-surface-200 bg-surface-50">
                          {[
                            "#",
                            "Name",
                            "Card No",
                            "Department",
                            "Designation",
                            "Joining Date",
                          ].map((h) => (
                            <th
                              key={h}
                              className="px-3 py-2 text-left font-semibold uppercase tracking-wider text-surface-500"
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-surface-100">
                        {importRows.slice(0, 10).map((r, i) => (
                          <tr key={i} className="hover:bg-surface-50">
                            <td className="px-3 py-2 text-surface-400">
                              {i + 1}
                            </td>
                            <td className="px-3 py-2 font-medium text-gray-900">
                              {r.name || "—"}
                            </td>
                            <td className="px-3 py-2 text-surface-500">
                              {r.cardNo || r.empCode || "—"}
                            </td>
                            <td className="px-3 py-2 text-surface-500">
                              {r.department || r.location || "—"}
                            </td>
                            <td className="px-3 py-2 text-surface-500">
                              {r.designation || "—"}
                            </td>
                            <td className="px-3 py-2 text-surface-500">
                              {r.doj || "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {importRows.length > 10 && (
                      <p className="border-t border-surface-100 px-3 py-2 text-xs text-surface-400">
                        …and {importRows.length - 10} more rows
                      </p>
                    )}
                  </div>
                  <p className="text-xs text-surface-400">
                    Emails auto-generated as{" "}
                    <code className="rounded bg-surface-100 px-1">
                      name@albos.com
                    </code>
                    . Employees already in the system (matched by Card No or
                    name) will be skipped.
                  </p>
                </div>
              )}

              {/* Result */}
              {importResult && (
                <div
                  className={`rounded-2xl border p-5 ${importResult.created > 0 ? "border-green-200 bg-green-50" : "border-amber-200 bg-amber-50"}`}
                >
                  <div className="mb-4 flex items-center gap-2">
                    {importResult.created > 0 ? (
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-amber-600" />
                    )}
                    <p className="text-sm font-semibold text-gray-900">
                      {importResult.message}
                    </p>
                  </div>
                  <div className="mb-4 grid grid-cols-3 gap-3 text-center">
                    {[
                      ["Created", importResult.created, "text-green-700"],
                      ["Skipped", importResult.skipped, "text-amber-700"],
                      ["Total", importResult.total, "text-gray-700"],
                    ].map(([l, v, c]) => (
                      <div key={l} className="rounded-xl bg-white/70 py-3">
                        <p className={`text-2xl font-bold ${c}`}>{v}</p>
                        <p className="mt-0.5 text-xs text-surface-500">{l}</p>
                      </div>
                    ))}
                  </div>
                  {importResult.skippedList?.slice(0, 5).map((s, i) => (
                    <p key={i} className="text-xs text-amber-700">
                      • {s.name} — {s.reason}
                    </p>
                  ))}
                  {importResult.errors?.map((err, i) => (
                    <p key={i} className="text-xs text-red-600 mt-1">
                      • {err}
                    </p>
                  ))}
                </div>
              )}

              <div className="flex justify-end gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setImportModal(false)}
                  className="btn-secondary text-sm"
                >
                  {importResult ? "Close" : "Cancel"}
                </button>
                {!importResult && (
                  <button
                    type="button"
                    onClick={handleBulkImport}
                    disabled={
                      !importRows ||
                      importing ||
                      importParsing ||
                      !!importParseErr
                    }
                    className="btn-primary text-sm"
                  >
                    <Upload className="h-4 w-4" />
                    {importing
                      ? `Importing ${importRows?.length ?? ""}…`
                      : `Import ${importRows ? importRows.length + " Employees" : ""}`}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ VIEW EMPLOYEE PROFILE MODAL ═══════════ */}
      {viewEmployee && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
          onClick={() => setViewEmployee(null)}
        >
          <div
            className="w-full max-w-lg rounded-[28px] bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-surface-200 px-6 py-5">
              <h3 className="font-display text-xl font-bold text-gray-900">Employee Profile</h3>
              <button
                type="button"
                onClick={() => setViewEmployee(null)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="px-6 py-6 space-y-5">
              {/* Avatar + name */}
              <div className="flex items-center gap-4">
                {viewEmployee.avatar || viewEmployee.profilePic ? (
                  <img
                    src={viewEmployee.avatar || viewEmployee.profilePic}
                    alt={viewEmployee.name}
                    className="h-16 w-16 rounded-2xl object-cover"
                  />
                ) : (
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-100">
                    <span className="text-2xl font-bold text-brand-700">
                      {getInitials(viewEmployee.name)}
                    </span>
                  </div>
                )}
                <div>
                  <p className="text-lg font-bold text-gray-900">{viewEmployee.name}</p>
                  <p className="text-sm text-surface-400">
                    {viewEmployee.employeeId || "—"} • {viewEmployee.email}
                  </p>
                  <div className="mt-1 flex gap-2">
                    <span
                      className={`status-badge text-xs ${viewEmployee.isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
                    >
                      {viewEmployee.isActive ? "Active" : "Inactive"}
                    </span>
                    <span
                      className={`status-badge text-xs ${viewEmployee.role === "hr" ? "bg-purple-100 text-purple-700" : "bg-surface-100 text-surface-500"}`}
                    >
                      {viewEmployee.role}
                    </span>
                  </div>
                </div>
              </div>

              {/* Details grid */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: Building2, label: "Department", value: viewEmployee.department || "—" },
                  { icon: Briefcase, label: "Designation", value: viewEmployee.designation || viewEmployee.position || "—" },
                  { icon: Phone, label: "Phone", value: viewEmployee.phone || "—" },
                  { icon: CalendarDays, label: "Joined", value: viewEmployee.doj ? new Date(viewEmployee.doj).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" }) : "—" },
                  { icon: Fingerprint, label: "Fingerprint ID", value: viewEmployee.fingerprintId ?? "—" },
                  { icon: CalendarDays, label: "Leave Balance", value: `${viewEmployee.leaveBalance ?? 0} days` },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="rounded-2xl bg-surface-50 p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className="h-3.5 w-3.5 text-surface-400" />
                      <span className="text-xs font-semibold uppercase tracking-wider text-surface-400">{label}</span>
                    </div>
                    <p className="text-sm font-medium text-gray-800">{String(value)}</p>
                  </div>
                ))}
              </div>

              {/* Password */}
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="h-4 w-4 text-amber-600" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-amber-700">
                    Password (HR-set)
                  </span>
                </div>
                {viewEmployee.tempPassword ? (
                  <div className="flex items-center justify-between gap-3">
                    <span className="font-mono text-sm text-gray-900 break-all">
                      {showViewPw
                        ? viewEmployee.tempPassword
                        : "•".repeat(Math.min(viewEmployee.tempPassword.length, 14))}
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowViewPw((v) => !v)}
                      className="flex-shrink-0 text-amber-600 hover:text-amber-800"
                    >
                      {showViewPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                ) : (
                  <p className="text-sm italic text-surface-400">
                    Employee has changed their own password — not visible to HR.
                  </p>
                )}
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    const emp = viewEmployee;
                    setViewEmployee(null);
                    openResetPw(emp);
                  }}
                  className="btn-secondary text-sm"
                >
                  <KeyRound className="h-4 w-4" />
                  Reset Password
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const emp = viewEmployee;
                    setViewEmployee(null);
                    openEdit(emp);
                  }}
                  className="btn-primary text-sm"
                >
                  <Edit2 className="h-4 w-4" />
                  Edit Employee
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ RESET PASSWORD MODAL ═══════════ */}
      {resetPwTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
          onClick={() => setResetPwTarget(null)}
        >
          <div
            className="w-full max-w-md rounded-[28px] bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-surface-200 px-6 py-5">
              <div>
                <h3 className="font-display text-xl font-bold text-gray-900">
                  Reset Password
                </h3>
                <p className="mt-1 text-sm text-surface-400">
                  Setting a new password for{" "}
                  <span className="font-semibold text-gray-700">
                    {resetPwTarget.name}
                  </span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setResetPwTarget(null)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <form onSubmit={handleResetPassword} className="space-y-4 px-6 py-6">
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={resetPwShow ? "text" : "password"}
                    value={resetPwValue}
                    onChange={(e) => setResetPwValue(e.target.value)}
                    placeholder="Min 6 characters"
                    required
                    className="input-field pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setResetPwShow((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-surface-400 hover:text-brand-700"
                  >
                    {resetPwShow ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                  Confirm Password
                </label>
                <input
                  type={resetPwShow ? "text" : "password"}
                  value={resetPwConfirm}
                  onChange={(e) => setResetPwConfirm(e.target.value)}
                  placeholder="Re-enter new password"
                  required
                  className="input-field"
                />
              </div>
              <p className="rounded-2xl bg-amber-50 p-4 text-sm text-amber-800">
                The employee will be prompted to change this password on next
                login. The password will also be visible in the employee list
                until they change it.
              </p>
              <div className="flex justify-end gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setResetPwTarget(null)}
                  className="btn-secondary text-sm"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={resetPwSaving}
                  className="btn-primary text-sm"
                >
                  <KeyRound className="h-4 w-4" />
                  {resetPwSaving ? "Resetting…" : "Reset Password"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ═══════════ DEACTIVATE CONFIRM ═══════════ */}
      {deactivateId && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
          onClick={() => setDeactivateId("")}
        >
          <div
            className="w-full max-w-md rounded-[28px] bg-white p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="font-display text-xl font-bold text-gray-900">
              Deactivate Employee
            </h3>
            <p className="mt-2 text-sm leading-6 text-surface-500">
              This keeps attendance and payroll history intact while removing
              the employee from active operations.
            </p>
            <div className="mt-6 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeactivateId("")}
                className="btn-secondary text-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeactivate}
                className="btn-danger text-sm"
              >
                Deactivate
              </button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
