'use client';

import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { AlertTriangle, CheckCircle2, ChevronLeft, ChevronRight, Edit2, Info, Lock, Plus, ReceiptText, RefreshCw, X } from 'lucide-react';
import AppShell from '@/components/AppShell';
import EmptyState from '@/components/EmptyState';
import PageHeader from '@/components/PageHeader';
import SalarySlip from '@/components/SalarySlip';
import StatCard from '@/components/StatCard';
import { useAuth } from '@/lib/auth';
import { employeeAPI, payrollAPI } from '@/lib/api';
import {
  formatCurrency,
  getMonthLabel,
  getMonthOptions,
  getStatusTone,
  getYearOptions,
  shiftMonth,
} from '@/lib/utils';

function calcSalaryBreakdown(salary) {
  const baseSalary = salary.employeeId?.salary ?? 0;
  const totalWorkingDays = salary.workingDays || 0;
  const actualPresentDays = salary.daysPresent ?? 0;
  const lateMarks = salary.lateMarks ?? 0;

  // Every 3 late marks = 1 full day deduction; remaining 2 late marks = 0.5 day deduction
  const lateFullDayDed = Math.floor(lateMarks / 3);
  const lateHalfDayDed = lateMarks % 3 >= 2 ? 0.5 : 0;
  const lateDayDeductions = lateFullDayDed + lateHalfDayDed;

  const adjustedDays = Math.max(0, actualPresentDays - lateDayDeductions);
  const calculated = totalWorkingDays > 0
    ? (adjustedDays / totalWorkingDays) * baseSalary - 200
    : 0;

  return {
    baseSalary,
    totalWorkingDays,
    actualPresentDays,
    lateMarks,
    lateFullDayDed,
    lateHalfDayDed,
    lateDayDeductions,
    adjustedDays,
    calculated: Math.max(0, calculated),
  };
}

function EditModal({ salary, onClose, onDone }) {
  const [form, setForm] = useState({
    pf:              salary.pf              ?? 0,
    pt:              salary.pt              ?? 0,
    pfi:             salary.pfi             ?? 0,
    tc:              salary.tc              ?? 0,
    otherDeductions: salary.otherDeductions ?? 0,
  });
  const [saving, setSaving] = useState(false);

  const breakdown = calcSalaryBreakdown(salary);

  // Live-compute net payable as HR edits deductions
  const liveNet = Math.max(
    0,
    (salary.grossSalary ?? 0) -
    (salary.absentDeduction ?? 0) -
    (salary.lateDeduction ?? 0) -
    (salary.leaveDeduction ?? 0) -
    Number(form.pf || 0) -
    Number(form.pt || 0) -
    Number(form.pfi || 0) -
    Number(form.tc || 0) -
    Number(form.otherDeductions || 0),
  );

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await payrollAPI.update(salary._id, {
        pf:              Number(form.pf),
        pt:              Number(form.pt),
        pfi:             Number(form.pfi),
        tc:              Number(form.tc),
        otherDeductions: Number(form.otherDeductions),
        allowOverride: true,
        // backend recalculates netPayable automatically
      });
      toast.success('Payroll record updated.');
      onDone();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update payroll.');
    } finally {
      setSaving(false);
    }
  };

  const emp = salary.employeeId || {};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm">
      <div className="glass-card w-full max-w-lg p-6">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h3 className="font-display text-lg font-bold text-gray-900">Edit Payroll</h3>
            <p className="text-sm text-surface-400">{emp.name} · {salary.month}/{salary.year}</p>
          </div>
          <button type="button" onClick={onClose} className="text-surface-400 hover:text-surface-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Existing deduction summary */}
        <div className="mb-4 grid grid-cols-2 gap-3 rounded-2xl bg-surface-50 p-4 text-sm">
          <div>
            <p className="text-xs text-surface-400">Gross Salary</p>
            <p className="font-semibold text-gray-900">{formatCurrency(salary.grossSalary)}</p>
          </div>
          <div>
            <p className="text-xs text-surface-400">Absent Deduction</p>
            <p className="font-semibold text-gray-900">{formatCurrency(salary.absentDeduction)}</p>
          </div>
          <div>
            <p className="text-xs text-surface-400">Late Deduction</p>
            <p className="font-semibold text-gray-900">{formatCurrency(salary.lateDeduction)}</p>
          </div>
          <div>
            <p className="text-xs text-surface-400">Leave Deduction</p>
            <p className="font-semibold text-gray-900">{formatCurrency(salary.leaveDeduction)}</p>
          </div>
        </div>

        {/* Salary calculation breakdown */}
        <div className="mb-4 rounded-2xl border border-brand-100 bg-brand-50 p-4 text-sm">
          <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-brand-700">
            Salary Calculation
          </p>
          <div className="space-y-1.5 text-xs text-gray-700">
            <div className="flex justify-between">
              <span className="text-surface-500">Base Monthly Salary</span>
              <span className="font-medium">{formatCurrency(breakdown.baseSalary)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-surface-500">Total Working Days</span>
              <span className="font-medium">{breakdown.totalWorkingDays}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-surface-500">Actual Present Days</span>
              <span className="font-medium">{breakdown.actualPresentDays}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-surface-500">
                Late Marks ({breakdown.lateMarks})
                {breakdown.lateFullDayDed > 0 && ` → ${breakdown.lateFullDayDed} full day(s)`}
                {breakdown.lateHalfDayDed > 0 && ` + 0.5 day`}
              </span>
              <span className="font-medium text-red-600">−{breakdown.lateDayDeductions} day(s)</span>
            </div>
            <div className="flex justify-between border-t border-brand-200 pt-1.5">
              <span className="font-semibold text-gray-800">Adjusted Days</span>
              <span className="font-semibold">{breakdown.adjustedDays}</span>
            </div>
            <div className="flex justify-between text-xs text-surface-400 italic">
              <span>({breakdown.adjustedDays} / {breakdown.totalWorkingDays}) × {formatCurrency(breakdown.baseSalary)} − ₹200</span>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between rounded-xl bg-brand-100 px-3 py-2">
            <span className="text-xs font-semibold text-brand-800">Calculated Net Salary</span>
            <span className="text-base font-bold text-brand-900">{formatCurrency(breakdown.calculated)}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {[
              { key: 'pf',  label: 'Provident Fund (PF)' },
              { key: 'pt',  label: 'Professional Tax (PT)' },
              { key: 'pfi', label: 'PF Insurance (PFI)' },
              { key: 'tc',  label: 'Transport Charges (TC)' },
            ].map(({ key, label }) => (
              <div key={key}>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                  {label} (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={form[key]}
                  onChange={(e) => setForm((prev) => ({ ...prev, [key]: e.target.value }))}
                  className="input-field"
                  placeholder="0"
                />
              </div>
            ))}
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
              Other Deductions (₹)
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={form.otherDeductions}
              onChange={(e) => setForm((prev) => ({ ...prev, otherDeductions: e.target.value }))}
              className="input-field"
              placeholder="0"
            />
          </div>

          {/* Live net payable preview */}
          <div className="flex items-center justify-between rounded-2xl bg-brand-700 px-4 py-3 text-white">
            <span className="text-sm text-white/70">Calculated Net Payable</span>
            <span className="text-lg font-bold">{formatCurrency(liveNet)}</span>
          </div>

          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="btn-primary flex-1">
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
            <button type="button" onClick={onClose} className="btn-secondary flex-1">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function PayrollPage() {
  const { user, isHR } = useAuth();
  const today = new Date();
  const [monthState, setMonthState] = useState({ month: today.getMonth() + 1, year: today.getFullYear() });
  const [salaries, setSalaries] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [editSalary, setEditSalary] = useState(null);
  const [selectedSalary, setSelectedSalary] = useState(null);

  // HR generate form
  const [genEmployeeId, setGenEmployeeId] = useState('');
  const [otherDeductions, setOtherDeductions] = useState(0);
  const [showGenPanel, setShowGenPanel] = useState(false);

  // Attendance check state
  const [attCheck, setAttCheck] = useState(null);   // { withData, withoutData, employees[] }
  const [attChecking, setAttChecking] = useState(false);

  // Employee: selected month/year for own slip
  const [mySalary, setMySalary] = useState(null);
  const [myLoading, setMyLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    if (isHR) {
      loadPayroll();
      loadEmployees();
    } else {
      loadMySalary();
    }
  }, [user, monthState.month, monthState.year]);

  const loadPayroll = async () => {
    setLoading(true);
    try {
      const { data } = await payrollAPI.list({ month: monthState.month, year: monthState.year });
      setSalaries(data.salaries);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to load payroll records.');
    } finally {
      setLoading(false);
    }
  };

  const loadEmployees = async () => {
    try {
      const { data } = await employeeAPI.list({ isActive: true, limit: 300 });
      setEmployees(data.employees);
    } catch { /* silent */ }
  };

  const loadMySalary = async () => {
    setMyLoading(true);
    setMySalary(null);
    try {
      const { data } = await payrollAPI.my(monthState.month, monthState.year);
      setMySalary(data.salary);
    } catch (err) {
      if (err.response?.status !== 404) {
        toast.error(err.response?.data?.message || 'Failed to load salary slip.');
      }
    } finally {
      setMyLoading(false);
    }
  };

  const checkAttendance = async () => {
    setAttChecking(true);
    setAttCheck(null);
    try {
      const { data } = await payrollAPI.attendanceCheck(monthState.month, monthState.year);
      setAttCheck(data);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to check attendance data.');
    } finally {
      setAttChecking(false);
    }
  };

  const handleGenerate = async (e) => {
    e.preventDefault();
    setGenerating(true);
    try {
      const payload = {
        month: monthState.month,
        year: monthState.year,
        otherDeductions: Number(otherDeductions),
      };
      if (genEmployeeId) payload.employeeId = genEmployeeId;
      const { data } = await payrollAPI.generate(payload);
      toast.success(data.message || 'Payroll generated.');
      setShowGenPanel(false);
      setGenEmployeeId('');
      setOtherDeductions(0);
      setAttCheck(null);
      await loadPayroll();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to generate payroll.');
    } finally {
      setGenerating(false);
    }
  };

  const handleFinalise = async (id) => {
    try {
      await payrollAPI.finalise(id);
      toast.success('Salary slip finalised and published to employee.');
      await loadPayroll();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to finalise payroll.');
    }
  };

  const totalGross = salaries.reduce((sum, s) => sum + (s.grossSalary || 0), 0);
  const totalNet = salaries.reduce((sum, s) => sum + (s.netPayable || 0), 0);
  const totalFinalised = salaries.filter((s) => s.status === 'finalised').length;

  if (!isHR) {
    return (
      <AppShell>
        <div className="mx-auto max-w-4xl space-y-6">
          <PageHeader
            title="My Salary Slip"
            description="View your monthly salary slip once it has been published by HR."
          />

          <div className="glass-card p-4">
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => setMonthState((cur) => shiftMonth(cur, -1))}
                className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 hover:bg-surface-50"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <div className="rounded-2xl bg-surface-50 px-4 py-3 text-sm font-semibold text-gray-900">
                {getMonthLabel(monthState.year, monthState.month)}
              </div>
              <button
                type="button"
                onClick={() => setMonthState((cur) => shiftMonth(cur, 1))}
                className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 hover:bg-surface-50"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
              <select
                value={monthState.month}
                onChange={(e) => setMonthState((cur) => ({ ...cur, month: Number(e.target.value) }))}
                className="input-field min-w-[140px]"
              >
                {getMonthOptions().map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              <select
                value={monthState.year}
                onChange={(e) => setMonthState((cur) => ({ ...cur, year: Number(e.target.value) }))}
                className="input-field min-w-[120px]"
              >
                {getYearOptions(3).map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
          </div>

          {myLoading ? (
            <div className="glass-card p-10 text-center text-sm text-surface-400">Loading salary slip...</div>
          ) : mySalary ? (
            <SalarySlip salary={mySalary} />
          ) : (
            <EmptyState
              icon={ReceiptText}
              title="Salary slip not yet published"
              description="Your salary slip for this month has not been published by HR yet. Check back later."
            />
          )}
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl space-y-6">
        <PageHeader
          title="Payroll"
          description="Generate, review, edit, and finalise monthly salary records."
          actions={[
            <button key="gen" type="button" onClick={() => setShowGenPanel((v) => !v)} className="btn-primary text-sm">
              <Plus className="h-4 w-4" />
              Generate Payroll
            </button>,
          ]}
        />

        <div className="glass-card p-4">
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setMonthState((cur) => shiftMonth(cur, -1))}
              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 hover:bg-surface-50"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <div className="rounded-2xl bg-surface-50 px-4 py-3 text-sm font-semibold text-gray-900">
              {getMonthLabel(monthState.year, monthState.month)}
            </div>
            <button
              type="button"
              onClick={() => setMonthState((cur) => shiftMonth(cur, 1))}
              className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 hover:bg-surface-50"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <select
              value={monthState.month}
              onChange={(e) => setMonthState((cur) => ({ ...cur, month: Number(e.target.value) }))}
              className="input-field min-w-[140px]"
            >
              {getMonthOptions().map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <select
              value={monthState.year}
              onChange={(e) => setMonthState((cur) => ({ ...cur, year: Number(e.target.value) }))}
              className="input-field min-w-[120px]"
            >
              {getYearOptions(3).map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>
        </div>

        {showGenPanel && (
          <div className="glass-card p-6 space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-lg font-bold text-gray-900">
                  Generate Payroll — {getMonthLabel(monthState.year, monthState.month)}
                </h3>
                <p className="mt-0.5 text-sm text-surface-400">
                  Step 1: Check attendance data &nbsp;→&nbsp; Step 2: Run generation
                </p>
              </div>
              <button type="button" onClick={() => { setShowGenPanel(false); setAttCheck(null); }} className="text-surface-400 hover:text-surface-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Step 1 — Attendance health check */}
            <div className="rounded-2xl border border-surface-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Info className="h-4 w-4 text-brand-600" />
                  <span className="text-sm font-semibold text-gray-800">
                    Step 1 — Verify Attendance Data
                  </span>
                </div>
                <button
                  type="button"
                  onClick={checkAttendance}
                  disabled={attChecking}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-brand-200 bg-brand-50 px-3 py-1.5 text-xs font-semibold text-brand-700 hover:bg-brand-100 disabled:opacity-60"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${attChecking ? 'animate-spin' : ''}`} />
                  {attChecking ? 'Checking…' : 'Check Attendance'}
                </button>
              </div>

              {!attCheck && !attChecking && (
                <p className="text-xs text-surface-400 italic">
                  Click "Check Attendance" to verify how many employees have attendance records for {getMonthLabel(monthState.year, monthState.month)} before generating payroll.
                </p>
              )}

              {attCheck && (
                <div className="space-y-3">
                  {/* Summary chips */}
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-xl bg-surface-50 p-3 text-center">
                      <p className="text-xs text-surface-400">Total Employees</p>
                      <p className="text-lg font-bold text-gray-900">{attCheck.totalEmployees}</p>
                    </div>
                    <div className="rounded-xl bg-green-50 p-3 text-center">
                      <p className="text-xs text-green-600">With Attendance</p>
                      <p className="text-lg font-bold text-green-700">{attCheck.withData}</p>
                    </div>
                    <div className={`rounded-xl p-3 text-center ${attCheck.withoutData > 0 ? 'bg-red-50' : 'bg-surface-50'}`}>
                      <p className={`text-xs ${attCheck.withoutData > 0 ? 'text-red-600' : 'text-surface-400'}`}>No Attendance</p>
                      <p className={`text-lg font-bold ${attCheck.withoutData > 0 ? 'text-red-700' : 'text-surface-400'}`}>{attCheck.withoutData}</p>
                    </div>
                  </div>

                  {/* Warning if some have no data */}
                  {attCheck.withoutData > 0 && (
                    <div className="flex gap-2 rounded-xl border border-amber-200 bg-amber-50 p-3">
                      <AlertTriangle className="h-4 w-4 flex-shrink-0 text-amber-600 mt-0.5" />
                      <div className="text-xs text-amber-800">
                        <p className="font-semibold mb-1">
                          {attCheck.withoutData} employee(s) have NO attendance records for this month.
                        </p>
                        <p className="mb-1.5">Their salary will be calculated as fully absent (₹0 net payable). If you already uploaded attendance, their names may not have matched — check fingerprint IDs or names in the import file.</p>
                        <div className="flex flex-wrap gap-1">
                          {attCheck.employees.filter(e => !e.hasData).map(e => (
                            <span key={e._id} className="inline-block rounded-lg bg-amber-100 px-2 py-0.5 font-medium text-amber-900">
                              {e.name} ({e.employeeId || '—'})
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* All good */}
                  {attCheck.withoutData === 0 && (
                    <div className="flex items-center gap-2 rounded-xl border border-green-200 bg-green-50 p-3">
                      <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-green-600" />
                      <p className="text-xs font-semibold text-green-800">
                        All {attCheck.totalEmployees} employees have attendance data for this month. Ready to generate!
                      </p>
                    </div>
                  )}

                  {/* Per-employee detail table */}
                  <div className="overflow-hidden rounded-xl border border-surface-200">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-surface-50 border-b border-surface-200">
                          <th className="px-3 py-2 text-left text-surface-500 font-semibold">Employee</th>
                          <th className="px-3 py-2 text-center text-surface-500 font-semibold">Days Recorded</th>
                          <th className="px-3 py-2 text-center text-surface-500 font-semibold">Present</th>
                          <th className="px-3 py-2 text-center text-surface-500 font-semibold">Late</th>
                          <th className="px-3 py-2 text-center text-surface-500 font-semibold">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-surface-100">
                        {attCheck.employees.map((emp) => (
                          <tr key={emp._id} className={emp.hasData ? '' : 'bg-red-50/60'}>
                            <td className="px-3 py-2">
                              <p className="font-semibold text-gray-900">{emp.name}</p>
                              <p className="text-surface-400">{emp.employeeId || '—'} · {emp.department || '—'}</p>
                            </td>
                            <td className="px-3 py-2 text-center font-semibold text-gray-700">{emp.totalDays}</td>
                            <td className="px-3 py-2 text-center font-semibold text-green-700">{emp.presentDays}</td>
                            <td className="px-3 py-2 text-center font-semibold text-amber-700">{emp.lateDays}</td>
                            <td className="px-3 py-2 text-center">
                              {emp.hasData
                                ? <span className="status-badge bg-green-100 text-green-700">Ready</span>
                                : <span className="status-badge bg-red-100 text-red-700">No Data</span>
                              }
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            {/* Step 2 — Generate */}
            <div className="rounded-2xl border border-surface-200 p-4">
              <div className="flex items-center gap-2 mb-3">
                <Info className="h-4 w-4 text-brand-600" />
                <span className="text-sm font-semibold text-gray-800">Step 2 — Run Payroll Generation</span>
              </div>
              <form onSubmit={handleGenerate} className="grid gap-4 sm:grid-cols-[1fr_200px_auto]">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Employee (leave blank for all)
                  </label>
                  <select
                    value={genEmployeeId}
                    onChange={(e) => setGenEmployeeId(e.target.value)}
                    className="input-field"
                  >
                    <option value="">All Active Employees</option>
                    {employees.map((emp) => (
                      <option key={emp._id} value={emp._id}>
                        {emp.employeeId} – {emp.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
                    Other Deductions (₹)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={otherDeductions}
                    onChange={(e) => setOtherDeductions(e.target.value)}
                    className="input-field"
                    disabled={!genEmployeeId}
                    title={genEmployeeId ? '' : 'Select a specific employee to set other deductions'}
                    placeholder="0"
                  />
                </div>
                <div className="flex items-end">
                  <button type="submit" disabled={generating} className="btn-primary whitespace-nowrap">
                    {generating ? 'Generating…' : 'Run Generation'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard icon={ReceiptText} label="Total Gross" value={formatCurrency(totalGross)} tone="bg-brand-100 text-brand-700" subtext={`${salaries.length} records`} />
          <StatCard icon={ReceiptText} label="Total Net Payable" value={formatCurrency(totalNet)} tone="bg-green-100 text-green-700" subtext="After all deductions" />
          <StatCard icon={Lock} label="Finalised" value={totalFinalised} tone="bg-surface-100 text-surface-500" subtext={`of ${salaries.length} published`} />
        </div>

        <div className="glass-card overflow-hidden">
          {loading ? (
            <div className="p-10 text-center text-sm text-surface-400">Loading payroll records...</div>
          ) : salaries.length === 0 ? (
            <EmptyState
              icon={ReceiptText}
              title="No payroll records"
              description="Generate payroll for this month to create salary records."
              action={
                <button type="button" onClick={() => setShowGenPanel(true)} className="btn-primary text-sm">
                  <Plus className="h-4 w-4" />
                  Generate Payroll
                </button>
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1240px]">
                <thead>
                  <tr className="border-b border-surface-200 bg-surface-50">
                    {['Employee', 'Gross', 'Absent Ded.', 'Late Ded.', 'Leave Ded.', 'Other Ded.', 'Net Payable', 'Status', 'Actions'].map((h) => (
                      <th
                        key={h}
                        className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider text-surface-500 ${h === 'Actions' ? 'text-right' : 'text-left'}`}
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-100">
                  {salaries.map((salary) => {
                    const emp = salary.employeeId || {};
                    return (
                      <tr
                        key={salary._id}
                        className="hover:bg-surface-50/80 cursor-pointer"
                        onClick={() => setSelectedSalary(salary)}
                      >
                        <td className="px-5 py-4" onClick={(e) => e.stopPropagation()}>
                          <p className="text-sm font-semibold text-gray-900">{emp.name || '-'}</p>
                          <p className="text-xs text-surface-400">{emp.employeeId || '-'} · {emp.department || '-'}</p>
                        </td>
                        <td className="px-5 py-4 text-sm text-gray-700">{formatCurrency(salary.grossSalary)}</td>
                        <td className="px-5 py-4 text-sm text-red-600">{formatCurrency(salary.absentDeduction)}</td>
                        <td className="px-5 py-4 text-sm text-red-600">{formatCurrency(salary.lateDeduction)}</td>
                        <td className="px-5 py-4 text-sm text-red-600">{formatCurrency(salary.leaveDeduction)}</td>
                        <td className="px-5 py-4 text-sm text-red-600">{formatCurrency(salary.otherDeductions)}</td>
                        <td className="px-5 py-4 text-sm font-semibold text-gray-900">{formatCurrency(salary.netPayable)}</td>
                        <td className="px-5 py-4">
                          <span className={`status-badge ${getStatusTone(salary.status)}`}>{salary.status}</span>
                        </td>
                        <td className="px-5 py-4 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex justify-end gap-2">
                            {salary.status !== 'finalised' && (
                              <button
                                type="button"
                                onClick={() => setEditSalary(salary)}
                                className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-surface-200 text-surface-500 hover:border-brand-200 hover:bg-brand-50 hover:text-brand-700"
                                title="Edit"
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>
                            )}
                            {salary.status !== 'finalised' && (
                              <button
                                type="button"
                                onClick={() => handleFinalise(salary._id)}
                                className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-brand-200 bg-brand-50 px-3 text-xs font-medium text-brand-700 hover:bg-brand-100"
                                title="Finalise"
                              >
                                <Lock className="h-3.5 w-3.5" />
                                Finalise
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {selectedSalary && (
          <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-950/40 p-4 backdrop-blur-sm">
            <div className="my-8 w-full max-w-3xl">
              <div className="mb-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => setSelectedSalary(null)}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-white text-surface-500 shadow hover:text-surface-700"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <SalarySlip salary={selectedSalary} />
            </div>
          </div>
        )}

        {editSalary && (
          <EditModal
            salary={editSalary}
            onClose={() => setEditSalary(null)}
            onDone={() => { setEditSalary(null); loadPayroll(); }}
          />
        )}
      </div>
    </AppShell>
  );
}
