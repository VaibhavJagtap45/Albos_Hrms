﻿'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import toast from 'react-hot-toast';
import {
  Bell,
  CalendarCheck,
  CalendarRange,
  FileText,
  ReceiptText,
  Users,
} from 'lucide-react';
import AppShell from '@/components/AppShell';
import EmptyState from '@/components/EmptyState';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import { useAuth } from '@/lib/auth';
import {
  attendanceAPI,
  employeeAPI,
  holidayAPI,
  leaveAPI,
  noticeAPI,
  payrollAPI,
} from '@/lib/api';

import {
  formatDate,
  formatDateRange,
  getAttendanceSummary,
  getMonthLabel,
  getStatusTone,
  pluralize,
} from '@/lib/utils';

function Card({ title, description, children, action }) {
  return (
    <div className="glass-card p-5">
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <h3 className="font-display text-lg font-bold text-gray-900">{title}</h3>
          {description ? <p className="mt-1 text-sm text-surface-400">{description}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

export default function DashboardPage() {
  const { user, isHR } = useAuth();
  const today = new Date();
  const currentMonth = today.getMonth() + 1;
  const currentYear = today.getFullYear();

  const [loading, setLoading] = useState(true);
  const [hrData, setHrData] = useState({
    employeeStats: null,
    attendanceStats: null,
    pendingLeaves: [],
    salaries: [],
    notices: [],
    holidays: [],
  });
  const [employeeData, setEmployeeData] = useState({
    profile: null,
    attendance: null,
    leaves: [],
    notices: [],
    holidays: [],
  });

  useEffect(() => {
    if (user) {
      loadDashboard();
    }
  }, [user]);

  const loadDashboard = async () => {
    setLoading(true);
    try {
      if (isHR) {
        const [employeeStatsRes, attendanceStatsRes, pendingLeavesRes, payrollRes, noticesRes, holidaysRes] = await Promise.all([
          employeeAPI.stats(),
          attendanceAPI.stats(),
          leaveAPI.list({ status: 'pending' }),
          payrollAPI.list({ month: currentMonth, year: currentYear }),
          noticeAPI.list(),
          holidayAPI.list({ month: currentMonth, year: currentYear }),
        ]);

        setHrData({
          employeeStats: employeeStatsRes.data,
          attendanceStats: attendanceStatsRes.data,
          pendingLeaves: pendingLeavesRes.data.leaves,
          salaries: payrollRes.data.salaries,
          notices: noticesRes.data.notices,
          holidays: holidaysRes.data.holidays,
        });
        return;
      }

      const [profileRes, attendanceRes, leavesRes, noticesRes, holidaysRes] = await Promise.all([
        employeeAPI.getMe(),
        attendanceAPI.getMyMonth(currentMonth, currentYear),
        leaveAPI.my(),
        noticeAPI.my(),
        holidayAPI.list({ month: currentMonth, year: currentYear }),
      ]);

      setEmployeeData({
        profile: profileRes.data.employee,
        attendance: attendanceRes.data,
        leaves: leavesRes.data.leaves,
        notices: noticesRes.data.notices,
        holidays: holidaysRes.data.holidays,
      });
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to load dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  const monthLabel = getMonthLabel(currentYear, currentMonth);
  const upcomingHolidays = (isHR ? hrData.holidays : employeeData.holidays)
    .filter((holiday) => new Date(holiday.date) >= new Date(today.toDateString()))
    .slice(0, 4);

  const employeeSummary = getAttendanceSummary(employeeData.attendance?.records || []);
  const unreadNotices = employeeData.notices.filter((notice) => notice.isRead === false).length;
  const pendingLeaves = employeeData.leaves.filter((leave) => leave.status === 'pending').length;
  const finalisedPayrollCount = hrData.salaries.filter((s) => s.status === 'finalised').length;

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl space-y-6">
        <PageHeader
          title={isHR ? 'HR Command Center' : 'My Dashboard'}
          description={
            isHR
              ? `Manage people operations for ${monthLabel}.`
              : `Track attendance, leave, payroll, and notices for ${monthLabel}.`
          }
          actions={
            isHR
              ? [
                  <Link key="employees" href="/employees" className="btn-secondary text-sm">
                    <Users className="h-4 w-4" />
                    Manage Employees
                  </Link>,
                  <Link key="payroll" href="/payroll" className="btn-primary text-sm">
                    <ReceiptText className="h-4 w-4" />
                    Run Payroll
                  </Link>,
                ]
              : [
                  <Link key="attendance" href="/attendance" className="btn-secondary text-sm">
                    <CalendarCheck className="h-4 w-4" />
                    View Attendance
                  </Link>,
                  <Link key="leaves" href="/leaves" className="btn-primary text-sm">
                    <CalendarRange className="h-4 w-4" />
                    Apply Leave
                  </Link>,
                ]
          }
        />

        {isHR ? (
          <>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard
                icon={Users}
                label="Total Employees"
                value={hrData.employeeStats?.totalEmployees ?? 0}
                tone="bg-brand-100 text-brand-700"
                subtext={`${hrData.employeeStats?.activeEmployees ?? 0} active employees`}
              />
              <StatCard
                icon={CalendarCheck}
                label="Present Today"
                value={hrData.attendanceStats?.todayPresent ?? 0}
                tone="bg-green-100 text-green-700"
                subtext={`${hrData.attendanceStats?.todayPunches ?? 0} punch events today`}
              />
              <StatCard
                icon={CalendarRange}
                label="Pending Leave Requests"
                value={hrData.pendingLeaves.length}
                tone="bg-amber-100 text-amber-700"
                subtext="Awaiting HR decision"
              />
              <StatCard
                icon={ReceiptText}
                label="Payroll Generated"
                value={hrData.salaries.length}
                tone="bg-purple-100 text-purple-700"
                subtext={`${finalisedPayrollCount} finalised this month`}
              />
            </div>

            <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
              <Card
                title="Pending Leave Queue"
                description="Requests that need approval or rejection from HR."
                action={<Link href="/leaves" className="text-sm font-semibold text-brand-700">Open Leaves</Link>}
              >
                {hrData.pendingLeaves.length ? (
                  <div className="space-y-3">
                    {hrData.pendingLeaves.slice(0, 5).map((leave) => (
                      <div key={leave._id} className="rounded-2xl border border-surface-200 p-4">
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{leave.employeeId?.name}</p>
                            <p className="mt-1 text-xs text-surface-400">
                              {leave.employeeId?.department || 'No department'}
                            </p>
                            <p className="mt-2 text-sm text-surface-500">
                              {formatDateRange(leave.fromDate, leave.toDate)}
                            </p>
                          </div>
                          <div className="text-left sm:text-right">
                            <span className={`status-badge ${getStatusTone(leave.status)}`}>{leave.status}</span>
                            <p className="mt-2 text-sm text-surface-500">{pluralize(leave.days, 'day')}</p>
                          </div>
                        </div>
                        <p className="mt-3 text-sm text-surface-500">{leave.reason}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={CalendarRange}
                    title="No pending leave requests"
                    description="You are all caught up. New leave requests will appear here."
                  />
                )}
              </Card>

              <div className="space-y-6">
                <Card
                  title="Payroll Snapshot"
                  description={`Generated salary slips for ${monthLabel}.`}
                  action={<Link href="/payroll" className="text-sm font-semibold text-brand-700">View Payroll</Link>}
                >
                  <div className="space-y-3">
                    <div className="rounded-2xl bg-surface-50 p-4">
                      <p className="text-xs uppercase tracking-wider text-surface-400">Draft Slips</p>
                      <p className="mt-1 font-display text-2xl font-bold text-gray-900">
                        {hrData.salaries.length - finalisedPayrollCount}
                      </p>
                    </div>
                    <div className="rounded-2xl bg-surface-50 p-4">
                      <p className="text-xs uppercase tracking-wider text-surface-400">Finalised Slips</p>
                      <p className="mt-1 font-display text-2xl font-bold text-gray-900">{finalisedPayrollCount}</p>
                    </div>
                  </div>
                </Card>

                <Card
                  title="Upcoming Holidays"
                  description="This month's planned holidays."
                  action={<Link href="/holidays" className="text-sm font-semibold text-brand-700">Holiday List</Link>}
                >
                  {upcomingHolidays.length ? (
                    <div className="space-y-3">
                      {upcomingHolidays.map((holiday) => (
                        <div key={holiday._id} className="flex items-center justify-between rounded-2xl bg-surface-50 px-4 py-3">
                          <div>
                            <p className="text-sm font-semibold text-gray-900">{holiday.name}</p>
                            <p className="text-xs capitalize text-surface-400">{holiday.type}</p>
                          </div>
                          <p className="text-sm font-semibold text-brand-700">{formatDate(holiday.date, 'dd MMM')}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="rounded-2xl bg-surface-50 p-4 text-sm text-surface-400">
                      No more holidays are scheduled for this month.
                    </p>
                  )}
                </Card>
              </div>
            </div>

            <Card
              title="Recent Notices"
              description="Latest company and employee communication."
              action={<Link href="/notices" className="text-sm font-semibold text-brand-700">Notice Board</Link>}
            >
              {hrData.notices.length ? (
                <div className="grid gap-4 lg:grid-cols-3">
                  {hrData.notices.slice(0, 3).map((notice) => (
                    <div key={notice._id} className="rounded-2xl border border-surface-200 p-4">
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-display text-lg font-bold text-gray-900">{notice.title}</p>
                        <span className="status-badge bg-surface-100 text-surface-500">{notice.type}</span>
                      </div>
                      <p className="mt-3 line-clamp-3 text-sm leading-6 text-surface-500">{notice.body}</p>
                      <div className="mt-4 flex items-center justify-between text-xs text-surface-400">
                        <span>{formatDate(notice.createdAt)}</span>
                        <span>{notice.readCount ?? 0} reads</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState
                  icon={Bell}
                  title="No notices published yet"
                  description="Publish your first announcement to communicate with the team."
                />
              )}
            </Card>
          </>
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-3">
              <StatCard
                icon={CalendarCheck}
                label="Days Present"
                value={employeeSummary.present + employeeSummary.late + employeeSummary['half-day']}
                tone="bg-green-100 text-green-700"
                subtext={`Attendance summary for ${monthLabel}`}
              />
              <StatCard
                icon={CalendarRange}
                label="Leave Balance"
                value={employeeData.profile?.leaveBalance ?? user?.leaveBalance ?? 0}
                tone="bg-blue-100 text-blue-700"
                subtext={`${pendingLeaves} request(s) pending`}
              />
              <StatCard
                icon={Bell}
                label="Unread Notices"
                value={unreadNotices}
                tone="bg-amber-100 text-amber-700"
                subtext={`${employeeData.notices.length} notice(s) available`}
              />
            </div>

            <Card
              title="Attendance Overview"
              description={`Your attendance status for ${monthLabel}.`}
              action={<Link href="/attendance" className="text-sm font-semibold text-brand-700">Open Calendar</Link>}
            >
              <div className="grid gap-3 sm:grid-cols-4">
                {[
                  ['Present', employeeSummary.present, 'text-green-700'],
                  ['Late', employeeSummary.late, 'text-amber-700'],
                  ['Leave', employeeSummary.leave + employeeSummary['half-day'], 'text-blue-700'],
                  ['Absent', employeeSummary.absent, 'text-red-700'],
                ].map(([label, value, tone]) => (
                  <div key={label} className="rounded-2xl bg-surface-50 p-4">
                    <p className="text-xs uppercase tracking-wider text-surface-400">{label}</p>
                    <p className={`mt-1 font-display text-2xl font-bold ${tone}`}>{value}</p>
                  </div>
                ))}
              </div>
            </Card>

            <div className="grid gap-6 xl:grid-cols-3">
              <Card
                title="Recent Leave Requests"
                description="Track approval progress on your requests."
                action={<Link href="/leaves" className="text-sm font-semibold text-brand-700">Manage Leaves</Link>}
              >
                {employeeData.leaves.length ? (
                  <div className="space-y-3">
                    {employeeData.leaves.slice(0, 4).map((leave) => (
                      <div key={leave._id} className="rounded-2xl bg-surface-50 p-4">
                        <div className="flex items-center justify-between gap-3">
                          <span className={`status-badge ${getStatusTone(leave.status)}`}>{leave.status}</span>
                          <span className="text-xs text-surface-400">{pluralize(leave.days, 'day')}</span>
                        </div>
                        <p className="mt-3 text-sm font-semibold text-gray-900">
                          {formatDateRange(leave.fromDate, leave.toDate)}
                        </p>
                        <p className="mt-1 text-sm text-surface-500">{leave.reason}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={CalendarRange}
                    title="No leave history yet"
                    description="Your leave requests will appear here once you submit one."
                  />
                )}
              </Card>

              <Card
                title="Unread Notices"
                description="Important communication from HR and leadership."
                action={<Link href="/notices" className="text-sm font-semibold text-brand-700">Open Notices</Link>}
              >
                {employeeData.notices.length ? (
                  <div className="space-y-3">
                    {employeeData.notices.slice(0, 4).map((notice) => (
                      <div key={notice._id} className="rounded-2xl bg-surface-50 p-4">
                        <div className="flex items-center justify-between gap-3">
                          <p className="text-sm font-semibold text-gray-900">{notice.title}</p>
                          <span className={`status-badge ${getStatusTone(notice.isRead ? 'draft' : 'finalised')}`}>
                            {notice.isRead ? 'Read' : 'Unread'}
                          </span>
                        </div>
                        <p className="mt-2 line-clamp-3 text-sm text-surface-500">{notice.body}</p>
                        <p className="mt-3 text-xs text-surface-400">{formatDate(notice.createdAt)}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={Bell}
                    title="No notices available"
                    description="Published announcements will be visible here."
                  />
                )}
              </Card>

              <Card
                title="Upcoming Holidays"
                description="Company and national holidays in view."
                action={<Link href="/holidays" className="text-sm font-semibold text-brand-700">Holiday List</Link>}
              >
                {upcomingHolidays.length ? (
                  <div className="space-y-3">
                    {upcomingHolidays.map((holiday) => (
                      <div key={holiday._id} className="rounded-2xl bg-surface-50 p-4">
                        <p className="text-sm font-semibold text-gray-900">{holiday.name}</p>
                        <p className="mt-1 text-xs capitalize text-surface-400">{holiday.type}</p>
                        <p className="mt-3 text-sm text-brand-700">{formatDate(holiday.date)}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <EmptyState
                    icon={FileText}
                    title="No upcoming holidays"
                    description="Any published holidays for the selected month will show up here."
                  />
                )}
              </Card>
            </div>
          </>
        )}
      </div>
    </AppShell>
  );
}
