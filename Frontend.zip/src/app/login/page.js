﻿'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import toast from 'react-hot-toast';
import {
  ArrowRight,
  Eye,
  EyeOff,
  Fingerprint,
  IdCard,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';

export default function LoginPage() {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const { login, user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && user) {
      router.replace('/dashboard');
    }
  }, [loading, router, user]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    const normalizedIdentifier = identifier.trim();
    if (!normalizedIdentifier || !password) {
      toast.error('Enter your email or employee ID and password.');
      return;
    }

    setSubmitting(true);
    try {
      const loggedInUser = await login(normalizedIdentifier, password);
      toast.success(`Welcome back, ${loggedInUser.name}`);
      router.push('/dashboard');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Unable to sign in right now.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading && user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white" style={{ background: 'var(--bg-gradient)' }}>
      <div className="grid min-h-screen lg:grid-cols-[1.05fr_0.95fr]">
        <section className="relative hidden overflow-hidden lg:flex">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(92,124,250,0.18),transparent_35%),radial-gradient(circle_at_bottom_right,rgba(34,197,94,0.14),transparent_32%)]" />
          <div className="relative z-10 flex w-full flex-col justify-between p-12 xl:p-16">
            <div>
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 ring-1 ring-white/10 backdrop-blur">
                  <Fingerprint className="h-6 w-6 text-brand-300" />
                </div>
                <div>
                  <p className="font-display text-xl font-bold tracking-tight">HRMS</p>
                  <p className="text-sm text-white/45">Albos Technology</p>
                </div>
              </div>

              <div className="mt-16 max-w-xl">
                <p className="text-sm uppercase tracking-[0.28em] text-brand-300">Unified Workforce System</p>
                <h1 className="mt-5 font-display text-5xl font-bold leading-tight text-white">
                  Attendance, leave, payroll, and communication in one modern HRMS workspace.
                </h1>
                <p className="mt-6 max-w-lg text-base leading-7 text-white/60">
                  Sign in with your office email or employee ID to access dashboards built for HR teams and employees.
                </p>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-3">
              {[
                {
                  title: 'Attendance Calendar',
                  copy: 'Track monthly presence, late marks, holidays, and working hours.',
                },
                {
                  title: 'Leave Workflow',
                  copy: 'Submit, review, and action leave requests with proper status tracking.',
                },
                {
                  title: 'Payroll Ready',
                  copy: 'Generate salary slips from attendance and approved leave data.',
                },
              ].map((item) => (
                <div key={item.title} className="rounded-3xl border border-white/10 bg-white/5 p-5 backdrop-blur">
                  <p className="font-display text-lg font-bold text-white">{item.title}</p>
                  <p className="mt-2 text-sm leading-6 text-white/55">{item.copy}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="flex items-center justify-center px-5 py-10 sm:px-8 lg:px-12">
          <div className="w-full max-w-md">
            <div className="mb-8 lg:hidden">
              <div className="flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 ring-1 ring-white/10 backdrop-blur">
                  <Fingerprint className="h-5 w-5 text-brand-300" />
                </div>
                <div>
                  <p className="font-display text-lg font-bold tracking-tight">HRMS</p>
                  <p className="text-xs text-white/45">Albos Technology</p>
                </div>
              </div>
            </div>

            <div className="rounded-[28px] border border-white/10 bg-white/[0.06] p-7 shadow-2xl shadow-black/20 backdrop-blur-xl sm:p-8">
              <div className="mb-8">
                <p className="text-sm uppercase tracking-[0.22em] text-white/45">Secure Sign In</p>
                <h2 className="mt-3 font-display text-3xl font-bold text-white">Welcome back</h2>
                <p className="mt-2 text-sm leading-6 text-white/50">
                  Use your registered email address or employee ID to continue.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-white/55">
                    Email or Employee ID
                  </label>
                  <div className="relative">
                    <IdCard className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <input
                      type="text"
                      value={identifier}
                      onChange={(event) => setIdentifier(event.target.value)}
                      placeholder="hr@albostech.com or ALB001"
                      autoComplete="username"
                      className="w-full rounded-2xl border border-white/10 bg-white/[0.05] px-11 py-3.5 text-sm text-white placeholder:text-white/25 focus:border-brand-400/60 focus:outline-none focus:ring-2 focus:ring-brand-400/15"
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-white/55">
                    Password
                  </label>
                  <div className="relative">
                    <KeyRound className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-white/30" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      placeholder="Enter your password"
                      autoComplete="current-password"
                      className="w-full rounded-2xl border border-white/10 bg-white/[0.05] px-11 py-3.5 pr-12 text-sm text-white placeholder:text-white/25 focus:border-brand-400/60 focus:outline-none focus:ring-2 focus:ring-brand-400/15"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((value) => !value)}
                      className="absolute right-4 top-1/2 -translate-y-1/2 text-white/35 transition-colors hover:text-white/70"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-600 px-5 py-3.5 text-sm font-semibold text-white transition hover:bg-brand-500 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {submitting ? (
                    <span className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                  ) : (
                    <>
                      Sign In
                      <ArrowRight className="h-4 w-4" />
                    </>
                  )}
                </button>

                <div className="text-center">
                  <Link
                    href="/forgot-password"
                    className="text-sm text-white/45 transition hover:text-white/75"
                  >
                    Forgot your password?
                  </Link>
                </div>
              </form>

              <div className="mt-6 rounded-2xl border border-white/8 bg-white/[0.03] p-4">
                <div className="flex items-start gap-3">
                  <ShieldCheck className="mt-0.5 h-4 w-4 text-brand-300" />
                  <div>
                    <p className="text-sm font-semibold text-white">Access is role-based</p>
                    <p className="mt-1 text-xs leading-5 text-white/45">
                      HR can manage employees, payroll, holidays, and notices. Employees get attendance, leave, salary, and profile access.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
