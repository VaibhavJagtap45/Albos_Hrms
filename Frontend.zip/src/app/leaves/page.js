'use client';

import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { CalendarRange, Check, MessageSquare, Plus, X } from 'lucide-react';
import AppShell from '@/components/AppShell';
import EmptyState from '@/components/EmptyState';
import LeaveForm from '@/components/LeaveForm';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import { useAuth } from '@/lib/auth';
import { leaveAPI } from '@/lib/api';
import {
  formatDate,
  formatDateRange,
  getLeaveTypeLabel,
  getStatusTone,
} from '@/lib/utils';

function ConfirmModal({ title, description, onConfirm, onCancel, confirmLabel = 'Confirm', danger = false }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm">
      <div className="glass-card w-full max-w-sm p-6">
        <h3 className="font-display text-lg font-bold text-gray-900">{title}</h3>
        {description && <p className="mt-2 text-sm text-surface-500">{description}</p>}
        <div className="mt-5 flex gap-3">
          <button
            type="button"
            onClick={onConfirm}
            className={`btn-primary flex-1 ${danger ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500' : ''}`}
          >
            {confirmLabel}
          </button>
          <button type="button" onClick={onCancel} className="btn-secondary flex-1">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function ActionModal({ leave, action, onClose, onDone }) {
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (action === 'approve') {
        await leaveAPI.approve(leave._id, comment);
        toast.success('Leave approved.');
      } else {
        await leaveAPI.reject(leave._id, comment);
        toast.success('Leave rejected.');
      }
      onDone();
    } catch (err) {
      toast.error(err.response?.data?.message || `Failed to ${action} leave.`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/40 p-4 backdrop-blur-sm">
      <div className="glass-card w-full max-w-sm p-6">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-lg font-bold text-gray-900 capitalize">{action} Leave</h3>
          <button type="button" onClick={onClose} className="text-surface-400 hover:text-surface-600">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="mb-4 rounded-2xl bg-surface-50 p-4 text-sm">
          <p className="font-semibold text-gray-900">{leave.employeeId?.name || 'Employee'}</p>
          <p className="mt-1 text-surface-500">
            {getLeaveTypeLabel(leave.leaveType)} · {formatDateRange(leave.fromDate, leave.toDate)}
          </p>
          {leave.reason && <p className="mt-2 text-surface-500 italic">"{leave.reason}"</p>}
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-surface-500">
              Comment (optional)
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="input-field min-h-[80px] resize-y"
              placeholder={`Add a note for the ${action}...`}
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className={`btn-primary w-full ${action === 'reject' ? 'bg-red-600 hover:bg-red-700 focus:ring-red-500' : ''}`}
          >
            {saving ? 'Processing...' : `${action === 'approve' ? 'Approve' : 'Reject'} Leave`}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function LeavesPage() {
  const { user, isHR } = useAuth();
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showApply, setShowApply] = useState(false);
  const [applying, setApplying] = useState(false);
  const [actionModal, setActionModal] = useState(null); // { leave, action: 'approve'|'reject' }
  const [cancelId, setCancelId] = useState(null);

  useEffect(() => {
    if (user) loadLeaves();
  }, [user]);

  const loadLeaves = async () => {
    setLoading(true);
    try {
      const { data } = isHR ? await leaveAPI.list() : await leaveAPI.my();
      setLeaves(isHR ? data.leaves : data.leaves);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to load leaves.');
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async (formData) => {
    setApplying(true);
    try {
      await leaveAPI.apply(formData);
      toast.success('Leave application submitted.');
      setShowApply(false);
      await loadLeaves();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to apply for leave.');
    } finally {
      setApplying(false);
    }
  };

  const handleCancel = async () => {
    try {
      await leaveAPI.cancel(cancelId);
      toast.success('Leave cancelled.');
      setCancelId(null);
      await loadLeaves();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to cancel leave.');
    }
  };

  const pending = leaves.filter((l) => l.status === 'pending').length;
  const approved = leaves.filter((l) => l.status === 'approved').length;
  const rejected = leaves.filter((l) => l.status === 'rejected').length;

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl space-y-6">
        <PageHeader
          title="Leaves"
          description={isHR ? 'Review and manage all employee leave requests.' : 'Apply for leave and track your request status.'}
          actions={
            !isHR
              ? [
                  <button key="apply" type="button" onClick={() => setShowApply((v) => !v)} className="btn-primary text-sm">
                    <Plus className="h-4 w-4" />
                    {showApply ? 'Hide Form' : 'Apply for Leave'}
                  </button>,
                ]
              : undefined
          }
        />

        <div className="grid gap-4 sm:grid-cols-3">
          <StatCard icon={CalendarRange} label="Pending" value={pending} tone="bg-amber-100 text-amber-700" subtext="Awaiting decision" />
          <StatCard icon={CalendarRange} label="Approved" value={approved} tone="bg-green-100 text-green-700" subtext="Approved leaves" />
          <StatCard icon={CalendarRange} label="Rejected" value={rejected} tone="bg-red-100 text-red-700" subtext="Rejected requests" />
        </div>

        {!isHR && showApply && (
          <div className="glass-card p-6">
            <h3 className="mb-4 font-display text-lg font-bold text-gray-900">New Leave Request</h3>
            <LeaveForm onSubmit={handleApply} submitting={applying} />
          </div>
        )}

        <div className="glass-card overflow-hidden">
          {loading ? (
            <div className="p-10 text-center text-sm text-surface-400">Loading leave records...</div>
          ) : leaves.length === 0 ? (
            <EmptyState
              icon={CalendarRange}
              title="No leave records found"
              description={isHR ? 'No leave applications have been submitted yet.' : 'You have not submitted any leave applications.'}
              action={
                !isHR
                  ? <button type="button" onClick={() => setShowApply(true)} className="btn-primary text-sm"><Plus className="h-4 w-4" />Apply for Leave</button>
                  : undefined
              }
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px]">
                <thead>
                  <tr className="border-b border-surface-200 bg-surface-50">
                    {[
                      isHR ? 'Employee' : null,
                      'Leave Type',
                      'Duration',
                      'Days',
                      'Status',
                      'Reason',
                      'Applied On',
                      'Actions',
                    ]
                      .filter(Boolean)
                      .map((heading) => (
                        <th
                          key={heading}
                          className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider text-surface-500 ${heading === 'Actions' ? 'text-right' : 'text-left'}`}
                        >
                          {heading}
                        </th>
                      ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-surface-100">
                  {leaves.map((leave) => {
                    const emp = leave.employeeId || {};
                    const days = leave.days ?? (() => {
                      const from = new Date(leave.fromDate);
                      const to   = new Date(leave.toDate);
                      return Math.round((to - from) / 86400000) + 1;
                    })();
                    const canCancel = leave.status === 'pending' && (!isHR || leave.employeeId?._id === user?._id);

                    return (
                      <tr key={leave._id} className="hover:bg-surface-50/80">
                        {isHR && (
                          <td className="px-5 py-4">
                            <p className="text-sm font-semibold text-gray-900">{emp.name || '-'}</p>
                            <p className="text-xs text-surface-400">{emp.employeeId || '-'} · {emp.department || '-'}</p>
                          </td>
                        )}
                        <td className="px-5 py-4 text-sm text-gray-700">{getLeaveTypeLabel(leave.leaveType)}</td>
                        <td className="px-5 py-4 text-sm text-gray-700 whitespace-nowrap">{formatDateRange(leave.fromDate, leave.toDate)}</td>
                        <td className="px-5 py-4 text-sm text-gray-700">{days}</td>
                        <td className="px-5 py-4">
                          <span className={`status-badge ${getStatusTone(leave.status)}`}>{leave.status}</span>
                        </td>
                        <td className="px-5 py-4 max-w-[200px]">
                          <p className="truncate text-sm text-surface-500">{leave.reason || '-'}</p>
                        </td>
                        <td className="px-5 py-4 text-sm text-surface-400 whitespace-nowrap">{formatDate(leave.createdAt)}</td>
                        <td className="px-5 py-4 text-right">
                          <div className="flex justify-end gap-2">
                            {isHR && leave.status === 'pending' && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => setActionModal({ leave, action: 'approve' })}
                                  className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-green-200 bg-green-50 px-3 text-xs font-medium text-green-700 transition hover:bg-green-100"
                                >
                                  <Check className="h-3.5 w-3.5" />
                                  Approve
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setActionModal({ leave, action: 'reject' })}
                                  className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-red-200 bg-red-50 px-3 text-xs font-medium text-red-600 transition hover:bg-red-100"
                                >
                                  <X className="h-3.5 w-3.5" />
                                  Reject
                                </button>
                              </>
                            )}
                            {canCancel && (
                              <button
                                type="button"
                                onClick={() => setCancelId(leave._id)}
                                className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-surface-200 px-3 text-xs font-medium text-surface-500 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600"
                              >
                                <X className="h-3.5 w-3.5" />
                                Cancel
                              </button>
                            )}
                            {leave.comment && (
                              <span title={leave.comment} className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-surface-200 text-surface-400">
                                <MessageSquare className="h-3.5 w-3.5" />
                              </span>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {actionModal && (
        <ActionModal
          leave={actionModal.leave}
          action={actionModal.action}
          onClose={() => setActionModal(null)}
          onDone={() => { setActionModal(null); loadLeaves(); }}
        />
      )}

      {cancelId && (
        <ConfirmModal
          title="Cancel Leave Request"
          description="Are you sure you want to cancel this leave application?"
          confirmLabel="Cancel Leave"
          danger
          onConfirm={handleCancel}
          onCancel={() => setCancelId(null)}
        />
      )}
    </AppShell>
  );
}
