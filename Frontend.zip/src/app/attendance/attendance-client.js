﻿'use client';

import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import {
  CalendarCheck,
  ChevronLeft,
  ChevronRight,
  Download,
  FileUp,
  Plus,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import AppShell from '@/components/AppShell';
import AttendanceCalendar from '@/components/AttendanceCalendar';
import EmptyState from '@/components/EmptyState';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import { useAuth } from '@/lib/auth';
import { attendanceAPI, employeeAPI } from '@/lib/api';
import {
  formatDate,
  getMonthLabel,
  getMonthOptions,
  getStatusTone,
  getYearOptions,
  shiftMonth,
  toIsoDate,
} from '@/lib/utils';

const STATUS_OPTIONS = ['present', 'late', 'leave', 'half-day', 'absent'];
const EMPTY_FORM = {
  employeeId: '',
  date: toIsoDate(new Date()),
  status: 'present',
  checkIn: '',
  checkOut: '',
  note: '',
};

function Card({ title, description, children, action }) {
  return (
    <div className="glass-card p-5">
      <div className="mb-4 flex items-start justify-between gap-4">
        <div>
          <h3 className="font-display text-lg font-bold text-gray-900">{title}</h3>
          {description ? <p className="mt-1 text-sm text-surface-400">{description}</p> : null}
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

export default function AttendancePage() {
  const { user, isHR } = useAuth();
  const today = new Date();
  const [monthState, setMonthState] = useState({ month: today.getMonth() + 1, year: today.getFullYear() });
  const [loading, setLoading] = useState(true);

  const [employees, setEmployees] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [records, setRecords] = useState([]);
  const [holidays, setHolidays] = useState([]);
  const [selectedDate, setSelectedDate] = useState(today);
  const [importLogs, setImportLogs] = useState([]);
  const [activeTab, setActiveTab] = useState('records');

  const [departmentFilter, setDepartmentFilter] = useState('');
  const [employeeFilter, setEmployeeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const [showForm, setShowForm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [saving, setSaving] = useState(false);
  const [importing, setImporting] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [importResult, setImportResult] = useState(null);
  const [editRecord, setEditRecord] = useState(null);
  const [deleteId, setDeleteId] = useState('');
  const [form, setForm] = useState(EMPTY_FORM);

  useEffect(() => {
    if (!user) return;
    loadAttendance();
  }, [user, isHR, monthState.month, monthState.year, departmentFilter, employeeFilter, statusFilter, activeTab]);

  const loadAttendance = async () => {
    setLoading(true);
    try {
      if (isHR) {
        const recordPromise = attendanceAPI.list({
          month: monthState.month,
          year: monthState.year,
          department: departmentFilter || undefined,
          employeeId: employeeFilter || undefined,
          status: statusFilter || undefined,
          limit: 300,
        });

        const importPromise = activeTab === 'imports' ? attendanceAPI.importLogs() : Promise.resolve({ data: { logs: [] } });

        const [recordsRes, employeesRes, departmentsRes, importLogsRes] = await Promise.all([
          recordPromise,
          employeeAPI.list({ limit: 300, isActive: true }),
          employeeAPI.departments(),
          importPromise,
        ]);

        setRecords(recordsRes.data.records);
        setEmployees(employeesRes.data.employees);
        setDepartments(departmentsRes.data.departments);
        setImportLogs(importLogsRes.data.logs);
        setHolidays([]);
        return;
      }

      const { data } = await attendanceAPI.getMyMonth(monthState.month, monthState.year);
      setRecords(data.records);
      setHolidays(data.holidays);

      const defaultDate =
        monthState.month === today.getMonth() + 1 && monthState.year === today.getFullYear()
          ? today
          : new Date(monthState.year, monthState.month - 1, 1);

      setSelectedDate(defaultDate);
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to load attendance data.');
    } finally {
      setLoading(false);
    }
  };

  const openCreate = () => {
    setEditRecord(null);
    setForm({ ...EMPTY_FORM, date: toIsoDate(new Date(monthState.year, monthState.month - 1, today.getDate())) });
    setShowForm(true);
  };

  const openEdit = (record) => {
    const employee = record.employee || record.employeeId || {};
    setEditRecord(record);
    setForm({
      employeeId: employee._id || '',
      date: toIsoDate(record.date),
      status: record.status || 'present',
      checkIn: record.checkIn || '',
      checkOut: record.checkOut || '',
      note: record.note || '',
    });
    setShowForm(true);
  };

  const handleSaveRecord = async (event) => {
    event.preventDefault();
    setSaving(true);

    try {
      const payload = {
        employeeId: form.employeeId,
        date: form.date,
        status: form.status,
        note: form.note.trim(),
      };

      if (form.checkIn) payload.checkIn = form.checkIn;
      if (form.checkOut) payload.checkOut = form.checkOut;

      if (editRecord) {
        await attendanceAPI.update(editRecord._id, payload);
        toast.success('Attendance record updated.');
      } else {
        await attendanceAPI.create(payload);
        toast.success('Attendance record created.');
      }

      setShowForm(false);
      setForm(EMPTY_FORM);
      await loadAttendance();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to save attendance record.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    try {
      await attendanceAPI.delete(deleteId);
      toast.success('Attendance record deleted.');
      setDeleteId('');
      await loadAttendance();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to delete attendance record.');
    }
  };

  const handleImport = async () => {
    if (!selectedFile) {
      toast.error('Choose a file before importing.');
      return;
    }

    setImporting(true);
    try {
      const { data } = await attendanceAPI.bulkUpload(selectedFile);
      setImportResult(data);
      toast.success(data.message || 'Attendance file imported.');
      await loadAttendance();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to import attendance file.');
    } finally {
      setImporting(false);
    }
  };

  const recordStats = {
    total: records.length,
    present: records.filter((record) => record.status === 'present').length,
    late: records.filter((record) => record.status === 'late').length,
    leave: records.filter((record) => ['leave', 'half-day'].includes(record.status)).length,
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl space-y-6">
        <PageHeader
          title="Attendance"
          description={
            isHR
              ? 'Manage monthly attendance records, corrections, and imports.'
              : 'Review your monthly attendance calendar with daily details.'
          }
          actions={
            isHR
              ? [
                  <button key="import" type="button" onClick={() => setShowImport(true)} className="btn-secondary text-sm">
                    <Upload className="h-4 w-4" />
                    Import File
                  </button>,
                  <button key="create" type="button" onClick={openCreate} className="btn-primary text-sm">
                    <Plus className="h-4 w-4" />
                    New Record
                  </button>,
                ]
              : undefined
          }
        />

        <div className="glass-card p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-2">
              <button type="button" onClick={() => setMonthState((current) => shiftMonth(current, -1))} className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:bg-surface-50">
                <ChevronLeft className="h-4 w-4" />
              </button>
              <div className="rounded-2xl bg-surface-50 px-4 py-3 text-sm font-semibold text-gray-900">
                {getMonthLabel(monthState.year, monthState.month)}
              </div>
              <button type="button" onClick={() => setMonthState((current) => shiftMonth(current, 1))} className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:bg-surface-50">
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:flex lg:items-center">
              <select value={monthState.month} onChange={(event) => setMonthState((current) => ({ ...current, month: Number(event.target.value) }))} className="input-field min-w-[160px]">
                {getMonthOptions().map((option) => (
                  <option key={option.value} value={option.value}>{option.label}</option>
                ))}
              </select>
              <select value={monthState.year} onChange={(event) => setMonthState((current) => ({ ...current, year: Number(event.target.value) }))} className="input-field min-w-[140px]">
                {getYearOptions(4).map((year) => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
        {isHR ? (
          <>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard icon={CalendarCheck} label="Records" value={recordStats.total} tone="bg-brand-100 text-brand-700" subtext="Attendance entries loaded" />
              <StatCard icon={CalendarCheck} label="Present" value={recordStats.present} tone="bg-green-100 text-green-700" subtext="Employees marked present" />
              <StatCard icon={CalendarCheck} label="Late" value={recordStats.late} tone="bg-amber-100 text-amber-700" subtext="Late arrivals in the month" />
              <StatCard icon={CalendarCheck} label="Leave" value={recordStats.leave} tone="bg-blue-100 text-blue-700" subtext="Leave and half-day records" />
            </div>

            <div className="glass-card p-4">
              <div className="grid gap-3 lg:grid-cols-[180px_220px_180px_1fr]">
                <select value={departmentFilter} onChange={(event) => setDepartmentFilter(event.target.value)} className="input-field">
                  <option value="">All Departments</option>
                  {departments.map((department) => (
                    <option key={department} value={department}>{department}</option>
                  ))}
                </select>
                <select value={employeeFilter} onChange={(event) => setEmployeeFilter(event.target.value)} className="input-field">
                  <option value="">All Employees</option>
                  {employees.map((employee) => (
                    <option key={employee._id} value={employee._id}>{employee.employeeId || 'Auto'} - {employee.name}</option>
                  ))}
                </select>
                <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} className="input-field">
                  <option value="">All Statuses</option>
                  {STATUS_OPTIONS.map((status) => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDepartmentFilter('');
                      setEmployeeFilter('');
                      setStatusFilter('');
                    }}
                    className="btn-secondary text-sm"
                  >
                    Reset Filters
                  </button>
                  <div className="ml-auto flex rounded-2xl bg-surface-100 p-1">
                    {['records', 'imports'].map((tab) => (
                      <button
                        key={tab}
                        type="button"
                        onClick={() => setActiveTab(tab)}
                        className={`rounded-xl px-3 py-2 text-sm font-medium ${activeTab === tab ? 'bg-white text-gray-900 shadow-sm' : 'text-surface-500'}`}
                      >
                        {tab === 'records' ? 'Records' : 'Import Logs'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {activeTab === 'records' ? (
              <div className="glass-card overflow-hidden">
                {loading ? (
                  <div className="p-10 text-center text-sm text-surface-400">Loading attendance records...</div>
                ) : records.length === 0 ? (
                  <EmptyState
                    icon={CalendarCheck}
                    title="No attendance records found"
                    description="Create a new attendance record or import attendance data for this month."
                    action={
                      <button type="button" onClick={openCreate} className="btn-primary text-sm">
                        <Plus className="h-4 w-4" />
                        New Record
                      </button>
                    }
                  />
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[1080px]">
                      <thead>
                        <tr className="border-b border-surface-200 bg-surface-50">
                          {['Employee', 'Date', 'Status', 'Check In', 'Check Out', 'Hours', 'Source', 'Actions'].map((heading) => (
                            <th key={heading} className={`px-5 py-3 text-xs font-semibold uppercase tracking-wider text-surface-500 ${heading === 'Actions' ? 'text-right' : 'text-left'}`}>
                              {heading}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-surface-100">
                        {records.map((record) => {
                          const employee = record.employee || record.employeeId || {};

                          return (
                            <tr key={record._id} className="hover:bg-surface-50/80">
                              <td className="px-5 py-4">
                                <div>
                                  <p className="text-sm font-semibold text-gray-900">{employee.name || 'Unknown Employee'}</p>
                                  <p className="text-xs text-surface-400">{employee.employeeId || '-'} - {employee.department || 'No department'}</p>
                                </div>
                              </td>
                              <td className="px-5 py-4 text-sm text-gray-700">{formatDate(record.date)}</td>
                              <td className="px-5 py-4">
                                <span className={`status-badge ${getStatusTone(record.status)}`}>{record.status}</span>
                              </td>
                              <td className="px-5 py-4 text-sm text-gray-700">{record.checkIn || '-'}</td>
                              <td className="px-5 py-4 text-sm text-gray-700">{record.checkOut || '-'}</td>
                              <td className="px-5 py-4 text-sm text-gray-700">{record.workingHours ? `${record.workingHours} hrs` : '-'}</td>
                              <td className="px-5 py-4 text-sm capitalize text-gray-700">{record.source || 'manual'}</td>
                              <td className="px-5 py-4 text-right">
                                <div className="flex justify-end gap-2">
                                  <button type="button" onClick={() => openEdit(record)} className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-brand-200 hover:bg-brand-50 hover:text-brand-700">
                                    <Plus className="h-4 w-4 rotate-45" />
                                  </button>
                                  <button type="button" onClick={() => setDeleteId(record._id)} className="inline-flex h-10 w-10 items-center justify-center rounded-2xl border border-surface-200 text-surface-500 transition hover:border-red-200 hover:bg-red-50 hover:text-red-600">
                                    <Trash2 className="h-4 w-4" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ) : (
              <Card title="Import History" description="Recent attendance import runs and processing results.">
                {loading ? (
                  <p className="text-sm text-surface-400">Loading import history...</p>
                ) : importLogs.length ? (
                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px]">
                      <thead>
                        <tr className="border-b border-surface-200 bg-surface-50">
                          {['Imported At', 'File', 'Status', 'Inserted', 'Skipped', 'Unmapped', 'Imported By'].map((heading) => (
                            <th key={heading} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-surface-500">{heading}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-surface-100">
                        {importLogs.map((log) => (
                          <tr key={log._id}>
                            <td className="px-4 py-3 text-sm text-gray-700">{formatDate(log.createdAt)}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{log.fileName || '-'}</td>
                            <td className="px-4 py-3"><span className={`status-badge ${getStatusTone(log.status)}`}>{log.status}</span></td>
                            <td className="px-4 py-3 text-sm text-gray-700">{log.recordsInserted}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{log.recordsSkipped}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{log.recordsUnmapped}</td>
                            <td className="px-4 py-3 text-sm text-gray-700">{log.importedBy?.name || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <EmptyState icon={Download} title="No imports yet" description="Imported attendance files will appear here with processing details." />
                )}
              </Card>
            )}
          </>
        ) : (
          <>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatCard icon={CalendarCheck} label="Present" value={records.filter((record) => record.status === 'present').length} tone="bg-green-100 text-green-700" subtext="Monthly present days" />
              <StatCard icon={CalendarCheck} label="Late" value={records.filter((record) => record.status === 'late').length} tone="bg-amber-100 text-amber-700" subtext="Monthly late arrivals" />
              <StatCard icon={CalendarCheck} label="Leave" value={records.filter((record) => ['leave', 'half-day'].includes(record.status)).length} tone="bg-blue-100 text-blue-700" subtext="Leave and half-day records" />
              <StatCard icon={CalendarCheck} label="Holidays" value={holidays.length} tone="bg-surface-100 text-surface-500" subtext="Published holidays in month" />
            </div>

            <Card title="Monthly Attendance Calendar" description="Select any date to view check-in, check-out, and holiday details.">
              {loading ? (
                <p className="text-sm text-surface-400">Loading your attendance calendar...</p>
              ) : (
                <AttendanceCalendar year={monthState.year} month={monthState.month} records={records} holidays={holidays} selectedDate={selectedDate} onSelectDate={setSelectedDate} />
              )}
            </Card>

            <Card title="Attendance Highlights" description="Recent daily records for the selected month.">
              {records.length ? (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[700px]">
                    <thead>
                      <tr className="border-b border-surface-200 bg-surface-50">
                        {['Date', 'Status', 'Check In', 'Check Out', 'Working Hours', 'Note'].map((heading) => (
                          <th key={heading} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-surface-500">{heading}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-surface-100">
                      {records.map((record) => (
                        <tr key={record._id}>
                          <td className="px-4 py-3 text-sm text-gray-700">{formatDate(record.date)}</td>
                          <td className="px-4 py-3"><span className={`status-badge ${getStatusTone(record.status)}`}>{record.status}</span></td>
                          <td className="px-4 py-3 text-sm text-gray-700">{record.checkIn || '-'}</td>
                          <td className="px-4 py-3 text-sm text-gray-700">{record.checkOut || '-'}</td>
                          <td className="px-4 py-3 text-sm text-gray-700">{record.workingHours ? `${record.workingHours} hrs` : '-'}</td>
                          <td className="px-4 py-3 text-sm text-gray-700">{record.note || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <EmptyState icon={CalendarCheck} title="No attendance records available" description="Your attendance will appear here once records are available for the selected month." />
              )}
            </Card>
          </>
        )}
      </div>
